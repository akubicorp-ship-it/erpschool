import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { ReactNode, useEffect } from "react";
import {
  LayoutDashboard, Database, FileText, CreditCard, BookOpen, Receipt, ScrollText,
  PieChart, Wallet, GraduationCap, LogOut, Bell, Search, ChevronRight,
  ShoppingCart, Package, Users2, Banknote, ClipboardList, Building2, TrendingUp,
  Lock, History, UserCircle2,
} from "lucide-react";
import { useStore, type Role } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

type NavItem = { to: string; label: string; icon: React.ComponentType<{ className?: string }>; roles: Role[] };
type NavGroup = { label: string; items: NavItem[] };

const NAV_GROUPS: NavGroup[] = [
  { label: "Overview", items: [
    { to: "/", label: "Executive Dashboard", icon: LayoutDashboard, roles: ["Administrator", "Cashier", "Accounting"] },
  ]},
  { label: "Master Data", items: [
    { to: "/master-data", label: "Students & Fees", icon: Database, roles: ["Administrator"] },
    { to: "/hr/employees", label: "Employees", icon: Users2, roles: ["Administrator"] },
    { to: "/purchasing/vendors", label: "Vendors & Items", icon: Building2, roles: ["Administrator"] },
  ]},
  { label: "Billing & Cashier", items: [
    { to: "/billing", label: "Bills Monitor", icon: FileText, roles: ["Administrator"] },
    { to: "/cashier", label: "Cashier POS", icon: CreditCard, roles: ["Administrator", "Cashier"] },
    { to: "/cashier/history", label: "Receipts History", icon: Receipt, roles: ["Administrator", "Cashier"] },
    { to: "/accounting/statement", label: "Student Statement", icon: UserCircle2, roles: ["Administrator", "Cashier", "Accounting"] },
  ]},
  { label: "Procurement & Inventory", items: [
    { to: "/purchasing/orders", label: "Purchase Orders", icon: ShoppingCart, roles: ["Administrator", "Accounting"] },
    { to: "/purchasing/receipts", label: "Goods Receipts", icon: Package, roles: ["Administrator", "Accounting"] },
  ]},
  { label: "HR & Payroll", items: [
    { to: "/hr/payroll", label: "Payroll Runs", icon: Banknote, roles: ["Administrator", "Accounting"] },
  ]},
  { label: "Accounting", items: [
    { to: "/accounting/coa", label: "Chart of Accounts", icon: Wallet, roles: ["Administrator", "Accounting"] },
    { to: "/accounting/journal", label: "General Journal", icon: ScrollText, roles: ["Administrator", "Accounting"] },
    { to: "/accounting/ledger", label: "General Ledger", icon: BookOpen, roles: ["Administrator", "Accounting"] },
    { to: "/accounting/budget", label: "Budget (RKAS)", icon: ClipboardList, roles: ["Administrator", "Accounting"] },
    { to: "/accounting/assets", label: "Fixed Assets", icon: Building2, roles: ["Administrator", "Accounting"] },
    { to: "/accounting/forecast", label: "Cash Forecast", icon: TrendingUp, roles: ["Administrator", "Accounting"] },
    { to: "/accounting/reports", label: "Financial Reports", icon: PieChart, roles: ["Administrator", "Accounting"] },
  ]},
  { label: "Governance", items: [
    { to: "/governance/close", label: "Period Close", icon: Lock, roles: ["Administrator", "Accounting"] },
    { to: "/governance/audit", label: "Audit Trail", icon: History, roles: ["Administrator", "Accounting"] },
  ]},
];

const ROUTE_TITLES: Record<string, string> = {
  "/": "Executive Dashboard", "/master-data": "Master Data",
  "/billing": "Bills Monitor", "/cashier": "Cashier POS", "/cashier/history": "Receipts History",
  "/accounting/coa": "Chart of Accounts", "/accounting/journal": "General Journal",
  "/accounting/ledger": "General Ledger", "/accounting/reports": "Financial Reports",
  "/accounting/budget": "Budget (RKAS)", "/accounting/assets": "Fixed Assets",
  "/accounting/forecast": "Cash Flow Forecast", "/accounting/statement": "Student Statement",
  "/hr/employees": "Employees", "/hr/payroll": "Payroll Runs",
  "/purchasing/vendors": "Vendors & Items", "/purchasing/orders": "Purchase Orders",
  "/purchasing/receipts": "Goods Receipts",
  "/governance/close": "Period Close", "/governance/audit": "Audit Trail",
};

export function AppLayout({ children }: { children: ReactNode }) {
  const currentUser = useStore((s) => s.currentUser);
  const role = useStore((s) => s.role);
  const logout = useStore((s) => s.logout);
  const activity = useStore((s) => s.activity);
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const navigate = useNavigate();

  // Gate: redirect to login if not authenticated. Login page renders without layout.
  useEffect(() => {
    if (!currentUser && pathname !== "/login") {
      navigate({ to: "/login" });
    }
  }, [currentUser, pathname, navigate]);

  if (pathname === "/login" || !currentUser) {
    return <>{children}</>;
  }

  const sectionTitle = ROUTE_TITLES[pathname] ?? "Workspace";

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="no-print w-64 shrink-0 bg-sidebar text-sidebar-foreground flex flex-col">
        <div className="p-5 border-b border-sidebar-border flex items-center gap-2">
          <div className="size-9 rounded-lg bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center">
            <GraduationCap className="size-5" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-sm leading-tight">EduFinance ERP</div>
            <div className="text-xs text-sidebar-foreground/60 truncate">SMP Harapan Bangsa</div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-4 overflow-y-auto">
          {NAV_GROUPS.map((group) => {
            const items = group.items.filter((n) => n.roles.includes(role));
            if (!items.length) return null;
            return (
              <div key={group.label}>
                <div className="px-3 mb-1.5 text-[10px] uppercase tracking-wider text-sidebar-foreground/40 font-semibold">
                  {group.label}
                </div>
                <div className="space-y-0.5">
                  {items.map((item) => {
                    const active = pathname === item.to || (item.to !== "/" && pathname.startsWith(item.to));
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.to}
                        to={item.to}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                          active
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                            : "hover:bg-sidebar-accent text-sidebar-foreground/80",
                        )}
                      >
                        <Icon className="size-4" />
                        {item.label}
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-2 px-2 py-2 rounded-md bg-sidebar-accent/40">
            <div className="size-8 rounded-full bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center text-xs font-semibold">
              {currentUser.initials}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-medium truncate">{currentUser.name}</div>
              <div className="text-[10px] text-sidebar-foreground/60 truncate">{currentUser.role}</div>
            </div>
          </div>
          <div className="text-[10px] text-sidebar-foreground/40 mt-2 px-2">v1.2 · Demo build</div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="no-print sticky top-0 z-10 bg-card/80 backdrop-blur border-b border-border px-6 py-2.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground min-w-0">
            <span>EduFinance</span>
            <ChevronRight className="size-3.5" />
            <span className="text-foreground font-medium truncate">{sectionTitle}</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative hidden md:block">
              <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search students, receipts…" className="pl-9 h-9 w-64 bg-background" />
            </div>

            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted/60 border border-border">
              <div className="size-1.5 rounded-full bg-success animate-pulse" />
              <div className="text-xs">
                <span className="text-muted-foreground">AY</span>{" "}
                <span className="font-medium">2025 / 2026</span>
              </div>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="size-4" />
                  {activity.length > 0 && (
                    <span className="absolute top-1.5 right-1.5 size-1.5 rounded-full bg-destructive" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Recent activity</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {activity.slice(0, 6).map((a) => (
                  <div key={a.id} className="px-2 py-2 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium">{a.action}</span>
                      <span className="text-muted-foreground">{new Date(a.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                    <div className="text-muted-foreground">
                      {a.user} · {a.role}
                      {a.detail ? ` · ${a.detail}` : ""}
                    </div>
                  </div>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 px-2">
                  <div className="size-7 rounded-full bg-primary text-primary-foreground grid place-items-center text-[11px] font-semibold">
                    {currentUser.initials}
                  </div>
                  <div className="text-left hidden sm:block">
                    <div className="text-xs font-medium leading-tight">{currentUser.name}</div>
                    <div className="text-[10px] text-muted-foreground leading-tight">{currentUser.role}</div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="text-sm font-medium">{currentUser.name}</div>
                  <div className="text-xs text-muted-foreground font-normal">{currentUser.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem disabled>
                  <Badge variant="secondary" className="mr-2">Role</Badge>
                  {currentUser.role}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => {
                    logout();
                    toast.success("Signed out");
                    navigate({ to: "/login" });
                  }}
                  className="text-destructive focus:text-destructive"
                >
                  <LogOut className="size-4" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function RoleGuard({ allow, children }: { allow: Role[]; children: ReactNode }) {
  const role = useStore((s) => s.role);
  if (!allow.includes(role)) {
    return (
      <div className="rounded-lg border bg-card p-10 text-center">
        <h2 className="text-lg font-semibold">Access restricted</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Your current role ({role}) does not have access to this page. Sign in with an account that has the right permissions.
        </p>
      </div>
    );
  }
  return <>{children}</>;
}
