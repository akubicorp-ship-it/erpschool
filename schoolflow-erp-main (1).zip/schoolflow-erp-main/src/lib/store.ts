import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export type Role = "Administrator" | "Cashier" | "Accounting";

export type DemoUser = {
  username: string;
  password: string;
  name: string;
  role: Role;
  email: string;
  initials: string;
};

export const DEMO_USERS: DemoUser[] = [
  { username: "admin", password: "admin123", name: "Rina Wijaya", role: "Administrator", email: "[email protected]", initials: "RW" },
  { username: "cashier", password: "cashier123", name: "Budi Santoso", role: "Cashier", email: "[email protected]", initials: "BS" },
  { username: "accountant", password: "acc123", name: "Sari Lestari", role: "Accounting", email: "[email protected]", initials: "SL" },
];

export type ActivityLog = {
  id: string;
  at: string;
  user: string;
  role: Role;
  action: string;
  detail?: string;
  module?: string;
  entityId?: string;
};

export type AcademicYear = { id: string; name: string; active: boolean };
export type ClassRoom = { id: string; name: string };
export type Student = {
  id: string;
  nis: string;
  name: string;
  classId: string;
  parentName: string;
  contact: string;
};
export type FeeType = {
  id: string;
  name: string;
  category: "Routine" | "Non-Routine";
  defaultAmount: number;
};
export type BankAccount = { id: string; bankName: string; accountNo: string; holder: string };

export type DocStatus = "Draft" | "Submitted" | "Approved" | "Rejected" | "Posted" | "Closed";

export type Bill = {
  id: string;
  studentId: string;
  feeTypeId: string;
  period: string;
  amount: number;
  paid: number;
  createdAt: string;
  dueDate?: string;
};

export type PaymentAllocation = { billId: string; amount: number };
export type Payment = {
  id: string;
  studentId: string;
  date: string;
  method: "Cash" | "Bank Transfer";
  bankAccountId?: string;
  allocations: PaymentAllocation[];
  total: number;
  cashier: string;
  receiptNo: string;
  journalId?: string;
};

export type Account = {
  code: string;
  name: string;
  type: "Asset" | "Liability" | "Equity" | "Income" | "Expense";
  parent?: string;
  openingBalance?: number;
};

export type JournalLine = { accountCode: string; debit: number; credit: number };
export type JournalEntry = {
  id: string;
  date: string;
  ref: string;
  description: string;
  source: "Auto" | "Manual";
  status: DocStatus;
  submittedBy?: string;
  approvedBy?: string;
  lines: JournalLine[];
  module?: string;
  sourceId?: string;
};

// ============= Procurement / Inventory =============
export type Vendor = { id: string; code: string; name: string; contact: string; address: string; taxId?: string };
export type Item = { id: string; code: string; name: string; unit: string; category: string; stock: number; avgCost: number };
export type POLine = { itemId: string; qty: number; price: number };
export type PurchaseOrder = {
  id: string;
  poNo: string;
  vendorId: string;
  date: string;
  lines: POLine[];
  status: DocStatus;
  submittedBy?: string;
  approvedBy?: string;
  receivedQty: Record<string, number>;
  total: number;
  notes?: string;
};
export type GoodsReceipt = {
  id: string;
  grNo: string;
  poId: string;
  date: string;
  lines: { itemId: string; qty: number }[];
  receivedBy: string;
  journalId?: string;
};

// ============= HR / Payroll =============
export type Employee = {
  id: string;
  nip: string;
  name: string;
  position: string;
  department: string;
  bankAccount: string;
  baseSalary: number;
  allowance: number;
  joinDate: string;
  active: boolean;
};
export type PayrollRun = {
  id: string;
  runNo: string;
  period: string;
  status: DocStatus;
  date: string;
  submittedBy?: string;
  approvedBy?: string;
  lines: { employeeId: string; base: number; allowance: number; deduction: number; net: number }[];
  total: number;
  journalId?: string;
};

// ============= Budget / RKAS =============
export type BudgetLine = {
  id: string;
  year: string;
  accountCode: string;
  category: string;
  description: string;
  planned: number;
  status: DocStatus;
  submittedBy?: string;
  approvedBy?: string;
};

// ============= Fixed Assets =============
export type FixedAsset = {
  id: string;
  code: string;
  name: string;
  category: string;
  acquisitionDate: string;
  cost: number;
  usefulLifeMonths: number;
  accumDepreciation: number;
  status: "Active" | "Disposed";
};

// ============= Period Close =============
export type ClosedPeriod = { period: string; closedAt: string; closedBy: string };

type State = {
  role: Role;
  setRole: (r: Role) => void;

  currentUser: DemoUser | null;
  login: (username: string, password: string) => DemoUser | null;
  logout: () => void;

  activity: ActivityLog[];
  logActivity: (action: string, detail?: string, module?: string, entityId?: string) => void;

  years: AcademicYear[];
  classes: ClassRoom[];
  students: Student[];
  feeTypes: FeeType[];
  bankAccounts: BankAccount[];
  bills: Bill[];
  payments: Payment[];
  accounts: Account[];
  journal: JournalEntry[];

  vendors: Vendor[];
  items: Item[];
  purchaseOrders: PurchaseOrder[];
  goodsReceipts: GoodsReceipt[];

  employees: Employee[];
  payrollRuns: PayrollRun[];

  budgetLines: BudgetLine[];

  fixedAssets: FixedAsset[];
  lastDepreciation?: string;

  closedPeriods: ClosedPeriod[];

  addYear: (y: Omit<AcademicYear, "id">) => void;
  updateYear: (id: string, patch: Partial<AcademicYear>) => void;
  removeYear: (id: string) => void;
  addClass: (c: Omit<ClassRoom, "id">) => void;
  updateClass: (id: string, patch: Partial<ClassRoom>) => void;
  removeClass: (id: string) => void;
  addStudent: (s: Omit<Student, "id">) => void;
  updateStudent: (id: string, patch: Partial<Student>) => void;
  removeStudent: (id: string) => void;
  addFeeType: (f: Omit<FeeType, "id">) => void;
  updateFeeType: (id: string, patch: Partial<FeeType>) => void;
  removeFeeType: (id: string) => void;
  addBank: (b: Omit<BankAccount, "id">) => void;
  updateBank: (id: string, patch: Partial<BankAccount>) => void;
  removeBank: (id: string) => void;

  generateBills: (input: {
    feeTypeId: string;
    classId?: string;
    studentIds?: string[];
    period: string;
    amount: number;
  }) => number;

  recordPayment: (input: {
    studentId: string;
    method: "Cash" | "Bank Transfer";
    bankAccountId?: string;
    allocations: PaymentAllocation[];
    cashier: string;
  }) => Payment;

  addManualJournal: (j: Omit<JournalEntry, "id" | "source" | "status">) => void;
  approveJournal: (id: string) => void;
  rejectJournal: (id: string) => void;

  // Procurement
  addVendor: (v: Omit<Vendor, "id">) => void;
  updateVendor: (id: string, p: Partial<Vendor>) => void;
  removeVendor: (id: string) => void;
  addItem: (i: Omit<Item, "id">) => void;
  updateItem: (id: string, p: Partial<Item>) => void;
  removeItem: (id: string) => void;
  createPO: (input: { vendorId: string; lines: POLine[]; notes?: string }) => PurchaseOrder;
  submitPO: (id: string) => void;
  approvePO: (id: string) => void;
  rejectPO: (id: string) => void;
  receiveGoods: (input: { poId: string; lines: { itemId: string; qty: number }[]; receivedBy: string }) => GoodsReceipt;

  // HR
  addEmployee: (e: Omit<Employee, "id">) => void;
  updateEmployee: (id: string, p: Partial<Employee>) => void;
  removeEmployee: (id: string) => void;
  createPayrollRun: (input: { period: string; deductionRate: number }) => PayrollRun;
  submitPayroll: (id: string) => void;
  approvePayroll: (id: string) => void;
  rejectPayroll: (id: string) => void;

  // Budget
  addBudgetLine: (b: Omit<BudgetLine, "id" | "status">) => void;
  updateBudgetLine: (id: string, p: Partial<BudgetLine>) => void;
  removeBudgetLine: (id: string) => void;
  submitBudget: (id: string) => void;
  approveBudget: (id: string) => void;
  rejectBudget: (id: string) => void;

  // Assets
  addAsset: (a: Omit<FixedAsset, "id" | "accumDepreciation" | "status">) => void;
  disposeAsset: (id: string) => void;
  runDepreciation: (period: string) => number;

  // Period close
  closePeriod: (period: string) => boolean;
  reopenPeriod: (period: string) => void;
  isPeriodClosed: (period: string) => boolean;
};

const uid = () => Math.random().toString(36).slice(2, 10);

const seedClasses: ClassRoom[] = [
  { id: "c1", name: "Grade 7A" },
  { id: "c2", name: "Grade 7B" },
  { id: "c3", name: "Grade 8A" },
  { id: "c4", name: "Grade 9A" },
];

const seedStudents: Student[] = [
  { id: "s1", nis: "2025001", name: "Andi Saputra", classId: "c1", parentName: "Bambang Saputra", contact: "0812-1111-0001" },
  { id: "s2", nis: "2025002", name: "Bunga Lestari", classId: "c1", parentName: "Citra Lestari", contact: "0812-1111-0002" },
  { id: "s3", nis: "2025003", name: "Citra Dewi", classId: "c2", parentName: "Dewi Anggraini", contact: "0812-1111-0003" },
  { id: "s4", nis: "2025004", name: "Dimas Pratama", classId: "c2", parentName: "Eko Pratama", contact: "0812-1111-0004" },
  { id: "s5", nis: "2025005", name: "Eka Putri", classId: "c3", parentName: "Fajar Putri", contact: "0812-1111-0005" },
  { id: "s6", nis: "2025006", name: "Fajar Hidayat", classId: "c3", parentName: "Gunawan Hidayat", contact: "0812-1111-0006" },
  { id: "s7", nis: "2025007", name: "Gita Ramadhani", classId: "c4", parentName: "Hadi Ramadhani", contact: "0812-1111-0007" },
  { id: "s8", nis: "2025008", name: "Hadi Wijaya", classId: "c4", parentName: "Indra Wijaya", contact: "0812-1111-0008" },
];

const seedFeeTypes: FeeType[] = [
  { id: "f1", name: "SPP Bulanan", category: "Routine", defaultAmount: 500000 },
  { id: "f2", name: "Kegiatan Semester", category: "Routine", defaultAmount: 350000 },
  { id: "f3", name: "Iuran Tahunan", category: "Routine", defaultAmount: 1200000 },
  { id: "f4", name: "Study Tour", category: "Non-Routine", defaultAmount: 850000 },
  { id: "f5", name: "Event Sekolah", category: "Non-Routine", defaultAmount: 150000 },
];

const seedAccounts: Account[] = [
  { code: "1100", name: "Cash on Hand", type: "Asset", openingBalance: 25000000 },
  { code: "1200", name: "Bank", type: "Asset", openingBalance: 150000000 },
  { code: "1300", name: "Student Receivables", type: "Asset", openingBalance: 0 },
  { code: "1400", name: "Inventory - Supplies", type: "Asset", openingBalance: 0 },
  { code: "1500", name: "Fixed Assets", type: "Asset", openingBalance: 80000000 },
  { code: "1510", name: "Accumulated Depreciation", type: "Asset", openingBalance: -15000000 },
  { code: "2100", name: "Accounts Payable", type: "Liability", openingBalance: 0 },
  { code: "2200", name: "Payroll Payable", type: "Liability", openingBalance: 0 },
  { code: "2300", name: "Tax Payable (PPh21)", type: "Liability", openingBalance: 0 },
  { code: "3100", name: "Capital / Opening Balance", type: "Equity", openingBalance: 240000000 },
  { code: "4100", name: "School Income - Tuition", type: "Income" },
  { code: "4200", name: "School Income - Activities", type: "Income" },
  { code: "5100", name: "Operational Expense - Utilities", type: "Expense" },
  { code: "5200", name: "Salary Expense", type: "Expense" },
  { code: "5300", name: "Supplies Expense", type: "Expense" },
  { code: "5400", name: "Depreciation Expense", type: "Expense" },
];

const currentPeriod = new Date().toISOString().slice(0, 7);
const seedBills: Bill[] = seedStudents.flatMap((s, idx): Bill[] => [
  { id: uid(), studentId: s.id, feeTypeId: "f1", period: currentPeriod, amount: 500000, paid: idx % 3 === 0 ? 500000 : idx % 3 === 1 ? 200000 : 0, createdAt: new Date(Date.now() - idx * 86400000 * 6).toISOString(), dueDate: new Date(Date.now() + 7 * 86400000).toISOString() },
  { id: uid(), studentId: s.id, feeTypeId: "f2", period: currentPeriod, amount: 350000, paid: 0, createdAt: new Date(Date.now() - idx * 86400000 * 6).toISOString(), dueDate: new Date(Date.now() + 14 * 86400000).toISOString() },
]);

const seedVendors: Vendor[] = [
  { id: "v1", code: "VEN-001", name: "PT Karya Pendidikan", contact: "021-555-0101", address: "Jl. Sudirman 12, Jakarta", taxId: "01.234.567.8-901.000" },
  { id: "v2", code: "VEN-002", name: "CV Sumber Buku", contact: "022-555-0202", address: "Jl. Asia Afrika 45, Bandung" },
  { id: "v3", code: "VEN-003", name: "PT Sinar Office", contact: "021-555-0303", address: "Jl. Gatot Subroto 88, Jakarta", taxId: "02.345.678.9-012.000" },
];

const seedItems: Item[] = [
  { id: "i1", code: "ITM-001", name: "Kertas A4 80gsm", unit: "Rim", category: "ATK", stock: 120, avgCost: 55000 },
  { id: "i2", code: "ITM-002", name: "Spidol Whiteboard", unit: "Box", category: "ATK", stock: 35, avgCost: 95000 },
  { id: "i3", code: "ITM-003", name: "Buku Pelajaran Matematika", unit: "Buah", category: "Buku", stock: 280, avgCost: 75000 },
  { id: "i4", code: "ITM-004", name: "Tinta Printer Hitam", unit: "Botol", category: "ATK", stock: 18, avgCost: 145000 },
  { id: "i5", code: "ITM-005", name: "Sabun Cuci Tangan", unit: "Liter", category: "Kebersihan", stock: 42, avgCost: 28000 },
];

const seedEmployees: Employee[] = [
  { id: "e1", nip: "NIP-1001", name: "Drs. Ahmad Yusuf", position: "Kepala Sekolah", department: "Manajemen", bankAccount: "BCA 1234567890", baseSalary: 12000000, allowance: 3500000, joinDate: "2015-07-01", active: true },
  { id: "e2", nip: "NIP-1002", name: "Siti Maryam, S.Pd", position: "Wakil Kurikulum", department: "Akademik", bankAccount: "BCA 1234567891", baseSalary: 9500000, allowance: 2500000, joinDate: "2017-08-15", active: true },
  { id: "e3", nip: "NIP-1003", name: "Bambang Wijaya, S.Pd", position: "Guru Matematika", department: "Akademik", bankAccount: "Mandiri 9876501", baseSalary: 7500000, allowance: 1500000, joinDate: "2019-01-10", active: true },
  { id: "e4", nip: "NIP-1004", name: "Dewi Lestari, S.Pd", position: "Guru Bahasa Indonesia", department: "Akademik", bankAccount: "Mandiri 9876502", baseSalary: 7200000, allowance: 1500000, joinDate: "2020-07-01", active: true },
  { id: "e5", nip: "NIP-1005", name: "Eko Prasetyo", position: "Staff Tata Usaha", department: "Administrasi", bankAccount: "BRI 0123456789", baseSalary: 5500000, allowance: 1000000, joinDate: "2021-03-15", active: true },
  { id: "e6", nip: "NIP-1006", name: "Pak Hadi", position: "Security", department: "Umum", bankAccount: "BRI 0123456790", baseSalary: 4200000, allowance: 800000, joinDate: "2018-06-01", active: true },
];

const yearStr = new Date().getFullYear().toString();
const seedBudget: BudgetLine[] = [
  { id: uid(), year: yearStr, accountCode: "5100", category: "Operasional", description: "Listrik & Air", planned: 60000000, status: "Approved", approvedBy: "Rina Wijaya" },
  { id: uid(), year: yearStr, accountCode: "5200", category: "SDM", description: "Gaji Pegawai", planned: 720000000, status: "Approved", approvedBy: "Rina Wijaya" },
  { id: uid(), year: yearStr, accountCode: "5300", category: "Operasional", description: "ATK & Supplies", planned: 36000000, status: "Approved", approvedBy: "Rina Wijaya" },
  { id: uid(), year: yearStr, accountCode: "5400", category: "Aset", description: "Penyusutan Tahunan", planned: 24000000, status: "Approved", approvedBy: "Rina Wijaya" },
  { id: uid(), year: yearStr, accountCode: "4100", category: "Pendapatan", description: "Target SPP", planned: 960000000, status: "Approved", approvedBy: "Rina Wijaya" },
];

const seedAssets: FixedAsset[] = [
  { id: uid(), code: "FA-001", name: "Komputer Lab IT (20 unit)", category: "Elektronik", acquisitionDate: "2022-01-15", cost: 180000000, usefulLifeMonths: 60, accumDepreciation: 87000000, status: "Active" },
  { id: uid(), code: "FA-002", name: "Proyektor Kelas (8 unit)", category: "Elektronik", acquisitionDate: "2023-06-01", cost: 48000000, usefulLifeMonths: 48, accumDepreciation: 22000000, status: "Active" },
  { id: uid(), code: "FA-003", name: "Meja & Kursi Siswa Set", category: "Furnitur", acquisitionDate: "2021-08-20", cost: 95000000, usefulLifeMonths: 120, accumDepreciation: 35000000, status: "Active" },
  { id: uid(), code: "FA-004", name: "Mobil Operasional Sekolah", category: "Kendaraan", acquisitionDate: "2020-03-10", cost: 220000000, usefulLifeMonths: 96, accumDepreciation: 130000000, status: "Active" },
];

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      role: "Administrator",
      setRole: (role) => set({ role }),

      currentUser: null,
      login: (username, password) => {
        const u = DEMO_USERS.find((x) => x.username === username && x.password === password);
        if (!u) return null;
        set({ currentUser: u, role: u.role });
        const log: ActivityLog = { id: uid(), at: new Date().toISOString(), user: u.name, role: u.role, action: "Signed in", module: "Auth" };
        set((s) => ({ activity: [log, ...s.activity] }));
        return u;
      },
      logout: () => {
        const u = get().currentUser;
        if (u) {
          const log: ActivityLog = { id: uid(), at: new Date().toISOString(), user: u.name, role: u.role, action: "Signed out", module: "Auth" };
          set((s) => ({ activity: [log, ...s.activity] }));
        }
        set({ currentUser: null });
      },

      activity: [
        { id: uid(), at: new Date(Date.now() - 1000 * 60 * 45).toISOString(), user: "System", role: "Administrator", action: "Period opened", detail: "Sep 2025", module: "System" },
        { id: uid(), at: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(), user: "Sari Lestari", role: "Accounting", action: "Posted manual journal", detail: "JV-202509-001", module: "Journal" },
        { id: uid(), at: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(), user: "Budi Santoso", role: "Cashier", action: "Issued receipt", detail: "RC-00012845", module: "Cashier" },
      ],
      logActivity: (action, detail, module, entityId) => {
        const u = get().currentUser;
        if (!u) return;
        const log: ActivityLog = { id: uid(), at: new Date().toISOString(), user: u.name, role: u.role, action, detail, module, entityId };
        set((s) => ({ activity: [log, ...s.activity].slice(0, 500) }));
      },

      years: [
        { id: "y1", name: "2024/2025", active: false },
        { id: "y2", name: "2025/2026", active: true },
      ],
      classes: seedClasses,
      students: seedStudents,
      feeTypes: seedFeeTypes,
      bankAccounts: [
        { id: "b1", bankName: "Bank Mandiri", accountNo: "123-456-789", holder: "SMP Harapan Bangsa" },
        { id: "b2", bankName: "BCA", accountNo: "987-654-321", holder: "SMP Harapan Bangsa" },
      ],
      bills: seedBills,
      payments: [],
      accounts: seedAccounts,
      journal: [],

      vendors: seedVendors,
      items: seedItems,
      purchaseOrders: [],
      goodsReceipts: [],

      employees: seedEmployees,
      payrollRuns: [],

      budgetLines: seedBudget,

      fixedAssets: seedAssets,
      closedPeriods: [],

      addYear: (y) => set((s) => ({ years: [...s.years, { ...y, id: uid() }] })),
      updateYear: (id, patch) => set((s) => ({ years: s.years.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      removeYear: (id) => set((s) => ({ years: s.years.filter((x) => x.id !== id) })),
      addClass: (c) => set((s) => ({ classes: [...s.classes, { ...c, id: uid() }] })),
      updateClass: (id, patch) => set((s) => ({ classes: s.classes.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      removeClass: (id) => set((s) => ({ classes: s.classes.filter((x) => x.id !== id) })),
      addStudent: (st) => set((s) => ({ students: [...s.students, { ...st, id: uid() }] })),
      updateStudent: (id, patch) => set((s) => ({ students: s.students.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      removeStudent: (id) => set((s) => ({ students: s.students.filter((x) => x.id !== id) })),
      addFeeType: (f) => set((s) => ({ feeTypes: [...s.feeTypes, { ...f, id: uid() }] })),
      updateFeeType: (id, patch) => set((s) => ({ feeTypes: s.feeTypes.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      removeFeeType: (id) => set((s) => ({ feeTypes: s.feeTypes.filter((x) => x.id !== id) })),
      addBank: (b) => set((s) => ({ bankAccounts: [...s.bankAccounts, { ...b, id: uid() }] })),
      updateBank: (id, patch) => set((s) => ({ bankAccounts: s.bankAccounts.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      removeBank: (id) => set((s) => ({ bankAccounts: s.bankAccounts.filter((x) => x.id !== id) })),

      generateBills: ({ feeTypeId, classId, studentIds, period, amount }) => {
        const s = get();
        let targets: Student[] = s.students;
        if (studentIds && studentIds.length) targets = targets.filter((st) => studentIds.includes(st.id));
        else if (classId) targets = targets.filter((st) => st.classId === classId);
        const newBills: Bill[] = targets
          .filter((st) => !s.bills.some((b) => b.studentId === st.id && b.feeTypeId === feeTypeId && b.period === period))
          .map((st) => ({
            id: uid(), studentId: st.id, feeTypeId, period, amount, paid: 0,
            createdAt: new Date().toISOString(),
            dueDate: new Date(Date.now() + 14 * 86400000).toISOString(),
          }));
        set({ bills: [...s.bills, ...newBills] });
        return newBills.length;
      },

      recordPayment: ({ studentId, method, bankAccountId, allocations, cashier }) => {
        const s = get();
        if (s.isPeriodClosed(new Date().toISOString().slice(0, 7))) {
          throw new Error("Periode berjalan sudah ditutup. Buka kembali untuk mencatat transaksi.");
        }
        const total = allocations.reduce((a, b) => a + b.amount, 0);
        const receiptNo = "RC-" + Date.now().toString().slice(-8);
        const debitAccount = method === "Cash" ? "1100" : "1200";
        const journalId = uid();
        const journalEntry: JournalEntry = {
          id: journalId, date: new Date().toISOString(), ref: receiptNo,
          description: `Payment from ${s.students.find((x) => x.id === studentId)?.name ?? ""}`,
          source: "Auto", status: "Posted", module: "Cashier", sourceId: receiptNo,
          lines: [
            { accountCode: debitAccount, debit: total, credit: 0 },
            { accountCode: "4100", debit: 0, credit: total },
          ],
        };
        const payment: Payment = { id: uid(), studentId, date: new Date().toISOString(), method, bankAccountId, allocations, total, cashier, receiptNo, journalId };
        const updatedBills = s.bills.map((b) => {
          const alloc = allocations.find((a) => a.billId === b.id);
          return alloc ? { ...b, paid: b.paid + alloc.amount } : b;
        });
        set({ bills: updatedBills, payments: [payment, ...s.payments], journal: [journalEntry, ...s.journal] });
        return payment;
      },

      addManualJournal: (j) => set((s) => ({ journal: [{ ...j, id: uid(), source: "Manual", status: "Submitted" }, ...s.journal] })),
      approveJournal: (id) => set((s) => ({ journal: s.journal.map((j) => j.id === id ? { ...j, status: "Posted", approvedBy: s.currentUser?.name } : j) })),
      rejectJournal: (id) => set((s) => ({ journal: s.journal.map((j) => j.id === id ? { ...j, status: "Rejected" } : j) })),

      // Procurement
      addVendor: (v) => set((s) => ({ vendors: [...s.vendors, { ...v, id: uid() }] })),
      updateVendor: (id, p) => set((s) => ({ vendors: s.vendors.map((x) => x.id === id ? { ...x, ...p } : x) })),
      removeVendor: (id) => set((s) => ({ vendors: s.vendors.filter((x) => x.id !== id) })),
      addItem: (i) => set((s) => ({ items: [...s.items, { ...i, id: uid() }] })),
      updateItem: (id, p) => set((s) => ({ items: s.items.map((x) => x.id === id ? { ...x, ...p } : x) })),
      removeItem: (id) => set((s) => ({ items: s.items.filter((x) => x.id !== id) })),
      createPO: ({ vendorId, lines, notes }) => {
        const total = lines.reduce((a, l) => a + l.qty * l.price, 0);
        const po: PurchaseOrder = {
          id: uid(), poNo: "PO-" + Date.now().toString().slice(-8), vendorId,
          date: new Date().toISOString(), lines, status: "Draft",
          receivedQty: {}, total, notes,
        };
        set((s) => ({ purchaseOrders: [po, ...s.purchaseOrders] }));
        return po;
      },
      submitPO: (id) => set((s) => ({ purchaseOrders: s.purchaseOrders.map((p) => p.id === id ? { ...p, status: "Submitted", submittedBy: s.currentUser?.name } : p) })),
      approvePO: (id) => set((s) => ({ purchaseOrders: s.purchaseOrders.map((p) => p.id === id ? { ...p, status: "Approved", approvedBy: s.currentUser?.name } : p) })),
      rejectPO: (id) => set((s) => ({ purchaseOrders: s.purchaseOrders.map((p) => p.id === id ? { ...p, status: "Rejected" } : p) })),
      receiveGoods: ({ poId, lines, receivedBy }) => {
        const s = get();
        const po = s.purchaseOrders.find((p) => p.id === poId)!;
        const gr: GoodsReceipt = { id: uid(), grNo: "GR-" + Date.now().toString().slice(-8), poId, date: new Date().toISOString(), lines, receivedBy };
        // Update stock
        const newItems = s.items.map((it) => {
          const ln = lines.find((l) => l.itemId === it.id);
          if (!ln) return it;
          const poLine = po.lines.find((l) => l.itemId === it.id);
          const price = poLine?.price ?? it.avgCost;
          const newStock = it.stock + ln.qty;
          const newAvg = newStock > 0 ? (it.stock * it.avgCost + ln.qty * price) / newStock : it.avgCost;
          return { ...it, stock: newStock, avgCost: newAvg };
        });
        // Update received qty
        const newReceived = { ...po.receivedQty };
        lines.forEach((l) => { newReceived[l.itemId] = (newReceived[l.itemId] ?? 0) + l.qty; });
        const fullyReceived = po.lines.every((pl) => (newReceived[pl.itemId] ?? 0) >= pl.qty);
        // Auto journal: DR Inventory, CR Accounts Payable
        const total = lines.reduce((a, l) => {
          const pl = po.lines.find((x) => x.itemId === l.itemId);
          return a + l.qty * (pl?.price ?? 0);
        }, 0);
        const journalEntry: JournalEntry = {
          id: uid(), date: gr.date, ref: gr.grNo,
          description: `Goods Receipt for ${po.poNo}`, source: "Auto", status: "Posted",
          module: "Procurement", sourceId: gr.id,
          lines: [
            { accountCode: "1400", debit: total, credit: 0 },
            { accountCode: "2100", debit: 0, credit: total },
          ],
        };
        gr.journalId = journalEntry.id;
        set({
          items: newItems,
          purchaseOrders: s.purchaseOrders.map((p) => p.id === poId ? { ...p, receivedQty: newReceived, status: fullyReceived ? "Closed" : "Approved" } : p),
          goodsReceipts: [gr, ...s.goodsReceipts],
          journal: [journalEntry, ...s.journal],
        });
        return gr;
      },

      // HR
      addEmployee: (e) => set((s) => ({ employees: [...s.employees, { ...e, id: uid() }] })),
      updateEmployee: (id, p) => set((s) => ({ employees: s.employees.map((x) => x.id === id ? { ...x, ...p } : x) })),
      removeEmployee: (id) => set((s) => ({ employees: s.employees.filter((x) => x.id !== id) })),
      createPayrollRun: ({ period, deductionRate }) => {
        const s = get();
        const lines = s.employees.filter((e) => e.active).map((e) => {
          const gross = e.baseSalary + e.allowance;
          const deduction = Math.round(gross * deductionRate);
          return { employeeId: e.id, base: e.baseSalary, allowance: e.allowance, deduction, net: gross - deduction };
        });
        const total = lines.reduce((a, l) => a + l.net, 0);
        const run: PayrollRun = {
          id: uid(), runNo: "PR-" + Date.now().toString().slice(-8), period,
          status: "Draft", date: new Date().toISOString(), lines, total,
        };
        set({ payrollRuns: [run, ...s.payrollRuns] });
        return run;
      },
      submitPayroll: (id) => set((s) => ({ payrollRuns: s.payrollRuns.map((p) => p.id === id ? { ...p, status: "Submitted", submittedBy: s.currentUser?.name } : p) })),
      approvePayroll: (id) => {
        const s = get();
        const run = s.payrollRuns.find((p) => p.id === id);
        if (!run) return;
        const totalGross = run.lines.reduce((a, l) => a + l.base + l.allowance, 0);
        const totalDed = run.lines.reduce((a, l) => a + l.deduction, 0);
        const journalEntry: JournalEntry = {
          id: uid(), date: new Date().toISOString(), ref: run.runNo,
          description: `Payroll ${run.period}`, source: "Auto", status: "Posted",
          module: "Payroll", sourceId: run.id,
          lines: [
            { accountCode: "5200", debit: totalGross, credit: 0 },
            { accountCode: "2300", debit: 0, credit: totalDed },
            { accountCode: "1200", debit: 0, credit: run.total },
          ],
        };
        set({
          payrollRuns: s.payrollRuns.map((p) => p.id === id ? { ...p, status: "Posted", approvedBy: s.currentUser?.name, journalId: journalEntry.id } : p),
          journal: [journalEntry, ...s.journal],
        });
      },
      rejectPayroll: (id) => set((s) => ({ payrollRuns: s.payrollRuns.map((p) => p.id === id ? { ...p, status: "Rejected" } : p) })),

      // Budget
      addBudgetLine: (b) => set((s) => ({ budgetLines: [...s.budgetLines, { ...b, id: uid(), status: "Draft" }] })),
      updateBudgetLine: (id, p) => set((s) => ({ budgetLines: s.budgetLines.map((x) => x.id === id ? { ...x, ...p } : x) })),
      removeBudgetLine: (id) => set((s) => ({ budgetLines: s.budgetLines.filter((x) => x.id !== id) })),
      submitBudget: (id) => set((s) => ({ budgetLines: s.budgetLines.map((b) => b.id === id ? { ...b, status: "Submitted", submittedBy: s.currentUser?.name } : b) })),
      approveBudget: (id) => set((s) => ({ budgetLines: s.budgetLines.map((b) => b.id === id ? { ...b, status: "Approved", approvedBy: s.currentUser?.name } : b) })),
      rejectBudget: (id) => set((s) => ({ budgetLines: s.budgetLines.map((b) => b.id === id ? { ...b, status: "Rejected" } : b) })),

      // Assets
      addAsset: (a) => set((s) => ({ fixedAssets: [...s.fixedAssets, { ...a, id: uid(), accumDepreciation: 0, status: "Active" }] })),
      disposeAsset: (id) => set((s) => ({ fixedAssets: s.fixedAssets.map((a) => a.id === id ? { ...a, status: "Disposed" } : a) })),
      runDepreciation: (period) => {
        const s = get();
        let totalDep = 0;
        const updated = s.fixedAssets.map((a) => {
          if (a.status !== "Active") return a;
          const monthly = a.cost / a.usefulLifeMonths;
          const remaining = a.cost - a.accumDepreciation;
          const dep = Math.min(monthly, remaining);
          totalDep += dep;
          return { ...a, accumDepreciation: a.accumDepreciation + dep };
        });
        if (totalDep === 0) return 0;
        const journalEntry: JournalEntry = {
          id: uid(), date: new Date().toISOString(), ref: `DEP-${period}`,
          description: `Monthly depreciation ${period}`, source: "Auto", status: "Posted",
          module: "Assets",
          lines: [
            { accountCode: "5400", debit: Math.round(totalDep), credit: 0 },
            { accountCode: "1510", debit: 0, credit: Math.round(totalDep) },
          ],
        };
        set({ fixedAssets: updated, lastDepreciation: period, journal: [journalEntry, ...s.journal] });
        return Math.round(totalDep);
      },

      // Period close
      closePeriod: (period) => {
        const s = get();
        if (s.closedPeriods.some((c) => c.period === period)) return false;
        const cp: ClosedPeriod = { period, closedAt: new Date().toISOString(), closedBy: s.currentUser?.name ?? "System" };
        set({ closedPeriods: [...s.closedPeriods, cp] });
        return true;
      },
      reopenPeriod: (period) => set((s) => ({ closedPeriods: s.closedPeriods.filter((c) => c.period !== period) })),
      isPeriodClosed: (period) => get().closedPeriods.some((c) => c.period === period),
    }),
    {
      name: "edufinance-erp-store-v2",
      version: 2,
      storage: createJSONStorage(() =>
        typeof window !== "undefined"
          ? window.localStorage
          : ({ getItem: () => null, setItem: () => {}, removeItem: () => {} } as unknown as Storage)
      ),
      partialize: (s) => ({
        currentUser: s.currentUser, role: s.role, activity: s.activity,
        years: s.years, classes: s.classes, students: s.students, feeTypes: s.feeTypes,
        bankAccounts: s.bankAccounts, bills: s.bills, payments: s.payments,
        accounts: s.accounts, journal: s.journal,
        vendors: s.vendors, items: s.items, purchaseOrders: s.purchaseOrders, goodsReceipts: s.goodsReceipts,
        employees: s.employees, payrollRuns: s.payrollRuns,
        budgetLines: s.budgetLines,
        fixedAssets: s.fixedAssets, lastDepreciation: s.lastDepreciation,
        closedPeriods: s.closedPeriods,
      }),
    }
  )
);

export const fmtIDR = (n: number) =>
  new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);

export const outstanding = (b: Bill) => b.amount - b.paid;
export const billStatus = (b: Bill): "Paid" | "Partially Paid" | "Unpaid" =>
  b.paid >= b.amount ? "Paid" : b.paid > 0 ? "Partially Paid" : "Unpaid";

export const statusTone = (s: DocStatus): string => {
  switch (s) {
    case "Draft": return "bg-muted text-muted-foreground";
    case "Submitted": return "bg-chart-3/15 text-chart-3";
    case "Approved": return "bg-primary/15 text-primary";
    case "Posted": return "bg-success/15 text-success";
    case "Rejected": return "bg-destructive/15 text-destructive";
    case "Closed": return "bg-secondary text-secondary-foreground";
  }
};

export function exportCSV(filename: string, rows: Record<string, string | number>[]) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const csv = [
    headers.join(","),
    ...rows.map((r) => headers.map((h) => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(",")),
  ].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
