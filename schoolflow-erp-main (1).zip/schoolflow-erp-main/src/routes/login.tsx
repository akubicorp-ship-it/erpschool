import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { DEMO_USERS, useStore } from "@/lib/store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, ShieldCheck, Lock, User as UserIcon } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — EduFinance ERP" }] }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const login = useStore((s) => s.login);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      const u = login(username.trim(), password);
      setLoading(false);
      if (!u) {
        toast.error("Invalid credentials", { description: "Use one of the demo accounts shown on the right." });
        return;
      }
      toast.success(`Welcome, ${u.name}`, { description: `Signed in as ${u.role}` });
      navigate({ to: "/" });
    }, 250);
  };

  const fill = (u: (typeof DEMO_USERS)[number]) => {
    setUsername(u.username);
    setPassword(u.password);
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-gradient-to-br from-sidebar to-[oklch(0.32_0.1_280)] text-sidebar-foreground">
      {/* Left brand panel */}
      <div className="hidden lg:flex flex-col justify-between p-12">
        <div className="flex items-center gap-3">
          <div className="size-11 rounded-xl bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center shadow-lg">
            <GraduationCap className="size-6" />
          </div>
          <div>
            <div className="font-semibold text-lg leading-tight">EduFinance ERP</div>
            <div className="text-xs text-sidebar-foreground/60">School Billing · Cashier · Accounting</div>
          </div>
        </div>

        <div className="space-y-6 max-w-md">
          <h1 className="text-4xl font-semibold leading-tight tracking-tight">
            One ledger.<br />Zero double entry.
          </h1>
          <p className="text-sidebar-foreground/70">
            An integrated ERP for school finance — cashier transactions automatically flow into the general
            journal, ledger, and financial statements in real time.
          </p>
          <div className="grid grid-cols-3 gap-3 pt-4">
            {[
              { v: "8", l: "Modules" },
              { v: "3", l: "Role tiers" },
              { v: "100%", l: "Auto-posted" },
            ].map((s) => (
              <div key={s.l} className="rounded-lg border border-sidebar-border/60 bg-sidebar-accent/30 p-4">
                <div className="text-2xl font-semibold">{s.v}</div>
                <div className="text-xs text-sidebar-foreground/60">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-sidebar-foreground/60">
          <ShieldCheck className="size-4" />
          Demo environment · No real financial data
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex items-center justify-center p-6 lg:p-12 bg-background text-foreground">
        <div className="w-full max-w-md space-y-6">
          <div className="lg:hidden flex items-center gap-2 mb-4">
            <div className="size-9 rounded-lg bg-primary text-primary-foreground grid place-items-center">
              <GraduationCap className="size-5" />
            </div>
            <div className="font-semibold">EduFinance ERP</div>
          </div>

          <Card className="border-border/80 shadow-xl">
            <CardHeader>
              <CardTitle className="text-xl">Sign in to your workspace</CardTitle>
              <CardDescription>Enter your credentials to access the ERP.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={submit} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="u">Username</Label>
                  <div className="relative">
                    <UserIcon className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input id="u" value={username} onChange={(e) => setUsername(e.target.value)} className="pl-9" placeholder="admin" autoComplete="username" required />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p">Password</Label>
                  <div className="relative">
                    <Lock className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input id="p" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="pl-9" placeholder="••••••••" autoComplete="current-password" required />
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Signing in..." : "Sign in"}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="border-dashed">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <ShieldCheck className="size-4 text-primary" /> Demo accounts
              </CardTitle>
              <CardDescription className="text-xs">Click any row to auto-fill the form.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {DEMO_USERS.map((u) => (
                <button
                  key={u.username}
                  type="button"
                  onClick={() => fill(u)}
                  className="w-full text-left flex items-center justify-between gap-2 rounded-md border border-border bg-card hover:bg-accent/50 transition-colors px-3 py-2"
                >
                  <div>
                    <div className="text-sm font-medium">{u.name}</div>
                    <div className="text-xs text-muted-foreground font-mono">{u.username} / {u.password}</div>
                  </div>
                  <Badge variant="secondary" className="text-[10px]">{u.role}</Badge>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
