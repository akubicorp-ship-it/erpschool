import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useStore, fmtIDR } from "@/lib/store";

export const Route = createFileRoute("/accounting/ledger")({
  head: () => ({ meta: [{ title: "General Ledger — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Ledger /></RoleGuard>,
});

function Ledger() {
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const [code, setCode] = useState(accounts[0]?.code ?? "");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const account = accounts.find((a) => a.code === code);

  const rows = useMemo(() => {
    const entries = journal
      .filter((j) => j.lines.some((l) => l.accountCode === code))
      .filter((j) => (!from || j.date >= from) && (!to || j.date <= to))
      .sort((a, b) => a.date.localeCompare(b.date));
    let bal = account?.openingBalance ?? 0;
    return entries.flatMap((j) =>
      j.lines.filter((l) => l.accountCode === code).map((l) => {
        bal += l.debit - l.credit;
        return { date: j.date, ref: j.ref, desc: j.description, debit: l.debit, credit: l.credit, balance: bal };
      })
    );
  }, [journal, code, from, to, account]);

  return (
    <div>
      <PageHeader title="General Ledger" description="Account transaction history" />
      <Card><CardContent className="p-5">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
          <div><Label>Account</Label>
            <Select value={code} onValueChange={setCode}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{accounts.map((a) => <SelectItem key={a.code} value={a.code}>{a.code} — {a.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>From</Label><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
          <div><Label>To</Label><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        </div>

        <div className="bg-muted rounded p-3 mb-3 flex justify-between text-sm">
          <span>Opening Balance</span>
          <span className="font-bold">{fmtIDR(account?.openingBalance ?? 0)}</span>
        </div>

        <Table>
          <TableHeader><TableRow>
            <TableHead>Date</TableHead><TableHead>Ref</TableHead><TableHead>Description</TableHead>
            <TableHead className="text-right">Debit</TableHead><TableHead className="text-right">Credit</TableHead>
            <TableHead className="text-right">Balance</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {rows.map((r, i) => (
              <TableRow key={i}>
                <TableCell>{new Date(r.date).toLocaleDateString()}</TableCell>
                <TableCell className="font-mono text-xs">{r.ref}</TableCell>
                <TableCell>{r.desc}</TableCell>
                <TableCell className="text-right">{r.debit ? fmtIDR(r.debit) : ""}</TableCell>
                <TableCell className="text-right">{r.credit ? fmtIDR(r.credit) : ""}</TableCell>
                <TableCell className="text-right font-medium">{fmtIDR(r.balance)}</TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6">No transactions for this account</TableCell></TableRow>
            )}
          </TableBody>
        </Table>

        <div className="bg-primary/10 text-primary rounded p-3 mt-3 flex justify-between text-sm font-semibold">
          <span>Ending Balance</span>
          <span>{fmtIDR(rows.length ? rows[rows.length - 1].balance : (account?.openingBalance ?? 0))}</span>
        </div>
      </CardContent></Card>
    </div>
  );
}
