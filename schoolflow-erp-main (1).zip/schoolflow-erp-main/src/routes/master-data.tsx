import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore, fmtIDR } from "@/lib/store";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/master-data")({
  head: () => ({ meta: [{ title: "Master Data — EduFinance ERP" }] }),
  component: () => (
    <RoleGuard allow={["Administrator"]}>
      <MasterData />
    </RoleGuard>
  ),
});

function MasterData() {
  return (
    <div>
      <PageHeader title="Master Data" description="Manage academic structure, students, fees and bank accounts" />
      <Tabs defaultValue="years">
        <TabsList className="mb-4">
          <TabsTrigger value="years">Academic Years</TabsTrigger>
          <TabsTrigger value="classes">Classes</TabsTrigger>
          <TabsTrigger value="students">Students</TabsTrigger>
          <TabsTrigger value="fees">Fee Types</TabsTrigger>
          <TabsTrigger value="banks">Bank Accounts</TabsTrigger>
        </TabsList>
        <TabsContent value="years"><YearsTab /></TabsContent>
        <TabsContent value="classes"><ClassesTab /></TabsContent>
        <TabsContent value="students"><StudentsTab /></TabsContent>
        <TabsContent value="fees"><FeesTab /></TabsContent>
        <TabsContent value="banks"><BanksTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function YearsTab() {
  const years = useStore((s) => s.years);
  const add = useStore((s) => s.addYear);
  const upd = useStore((s) => s.updateYear);
  const rm = useStore((s) => s.removeYear);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");

  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex justify-end mb-3">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="size-4 mr-1" />Add Year</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New Academic Year</DialogTitle></DialogHeader>
              <Label>Year Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="2026/2027" />
              <DialogFooter>
                <Button onClick={() => {
                  if (!name.trim()) return toast.error("Name required");
                  add({ name, active: false });
                  setName(""); setOpen(false); toast.success("Year added");
                }}>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <Table>
          <TableHeader><TableRow><TableHead>Year</TableHead><TableHead>Status</TableHead><TableHead className="w-32">Actions</TableHead></TableRow></TableHeader>
          <TableBody>
            {years.map((y) => (
              <TableRow key={y.id}>
                <TableCell className="font-medium">{y.name}</TableCell>
                <TableCell>
                  <Badge variant={y.active ? "default" : "secondary"}>{y.active ? "Active" : "Inactive"}</Badge>
                </TableCell>
                <TableCell>
                  <Button size="sm" variant="ghost" onClick={() => {
                    years.forEach((x) => upd(x.id, { active: false }));
                    upd(y.id, { active: true });
                    toast.success(`${y.name} set active`);
                  }}>Set Active</Button>
                  <Button size="sm" variant="ghost" onClick={() => rm(y.id)}><Trash2 className="size-4" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function ClassesTab() {
  const classes = useStore((s) => s.classes);
  const add = useStore((s) => s.addClass);
  const rm = useStore((s) => s.removeClass);
  const [name, setName] = useState("");
  return (
    <Card><CardContent className="p-5">
      <div className="flex gap-2 mb-4">
        <Input placeholder="Class name e.g. Grade 10A" value={name} onChange={(e) => setName(e.target.value)} className="max-w-xs" />
        <Button onClick={() => { if (!name) return; add({ name }); setName(""); toast.success("Class added"); }}>
          <Plus className="size-4 mr-1" />Add
        </Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Class Name</TableHead><TableHead className="w-24">Actions</TableHead></TableRow></TableHeader>
        <TableBody>
          {classes.map((c) => (
            <TableRow key={c.id}>
              <TableCell className="font-medium">{c.name}</TableCell>
              <TableCell><Button size="sm" variant="ghost" onClick={() => rm(c.id)}><Trash2 className="size-4" /></Button></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </CardContent></Card>
  );
}

function StudentsTab() {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const add = useStore((s) => s.addStudent);
  const rm = useStore((s) => s.removeStudent);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ nis: "", name: "", classId: "", parentName: "", contact: "" });
  const [q, setQ] = useState("");

  const filtered = students.filter((s) => s.name.toLowerCase().includes(q.toLowerCase()) || s.nis.includes(q));

  return (
    <Card><CardContent className="p-5">
      <div className="flex justify-between mb-3 gap-2">
        <Input placeholder="Search by name or NIS..." value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="size-4 mr-1" />Add Student</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Student</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div><Label>NIS</Label><Input value={form.nis} onChange={(e) => setForm({ ...form, nis: e.target.value })} /></div>
              <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label>Class</Label>
                <Select value={form.classId} onValueChange={(v) => setForm({ ...form, classId: v })}>
                  <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
                  <SelectContent>{classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Parent/Guardian</Label><Input value={form.parentName} onChange={(e) => setForm({ ...form, parentName: e.target.value })} /></div>
              <div><Label>Contact</Label><Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button onClick={() => {
                if (!form.nis || !form.name || !form.classId) return toast.error("NIS, Name and Class are required");
                add(form);
                setForm({ nis: "", name: "", classId: "", parentName: "", contact: "" });
                setOpen(false);
                toast.success("Student added");
              }}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <Table>
        <TableHeader><TableRow>
          <TableHead>NIS</TableHead><TableHead>Name</TableHead><TableHead>Class</TableHead><TableHead>Parent</TableHead><TableHead>Contact</TableHead><TableHead></TableHead>
        </TableRow></TableHeader>
        <TableBody>
          {filtered.map((s) => (
            <TableRow key={s.id}>
              <TableCell>{s.nis}</TableCell>
              <TableCell className="font-medium">{s.name}</TableCell>
              <TableCell>{classes.find((c) => c.id === s.classId)?.name}</TableCell>
              <TableCell>{s.parentName}</TableCell>
              <TableCell>{s.contact}</TableCell>
              <TableCell><Button size="sm" variant="ghost" onClick={() => rm(s.id)}><Trash2 className="size-4" /></Button></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </CardContent></Card>
  );
}

function FeesTab() {
  const fees = useStore((s) => s.feeTypes);
  const add = useStore((s) => s.addFeeType);
  const rm = useStore((s) => s.removeFeeType);
  const [form, setForm] = useState<{ name: string; category: "Routine" | "Non-Routine"; defaultAmount: number }>({ name: "", category: "Routine", defaultAmount: 0 });
  return (
    <Card><CardContent className="p-5">
      <div className="flex gap-2 mb-4 flex-wrap">
        <Input placeholder="Fee name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="max-w-xs" />
        <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as "Routine" | "Non-Routine" })}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="Routine">Routine</SelectItem><SelectItem value="Non-Routine">Non-Routine</SelectItem></SelectContent>
        </Select>
        <Input type="number" placeholder="Default amount" value={form.defaultAmount || ""} onChange={(e) => setForm({ ...form, defaultAmount: +e.target.value })} className="max-w-xs" />
        <Button onClick={() => { if (!form.name) return; add(form); setForm({ name: "", category: "Routine", defaultAmount: 0 }); toast.success("Fee type added"); }}>
          <Plus className="size-4 mr-1" />Add
        </Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Category</TableHead><TableHead>Default Amount</TableHead><TableHead></TableHead></TableRow></TableHeader>
        <TableBody>{fees.map((f) => (
          <TableRow key={f.id}>
            <TableCell className="font-medium">{f.name}</TableCell>
            <TableCell><Badge variant={f.category === "Routine" ? "default" : "secondary"}>{f.category}</Badge></TableCell>
            <TableCell>{fmtIDR(f.defaultAmount)}</TableCell>
            <TableCell><Button size="sm" variant="ghost" onClick={() => rm(f.id)}><Trash2 className="size-4" /></Button></TableCell>
          </TableRow>
        ))}</TableBody>
      </Table>
    </CardContent></Card>
  );
}

function BanksTab() {
  const banks = useStore((s) => s.bankAccounts);
  const add = useStore((s) => s.addBank);
  const rm = useStore((s) => s.removeBank);
  const [form, setForm] = useState({ bankName: "", accountNo: "", holder: "" });
  return (
    <Card><CardContent className="p-5">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-4">
        <Input placeholder="Bank name" value={form.bankName} onChange={(e) => setForm({ ...form, bankName: e.target.value })} />
        <Input placeholder="Account number" value={form.accountNo} onChange={(e) => setForm({ ...form, accountNo: e.target.value })} />
        <Input placeholder="Account holder" value={form.holder} onChange={(e) => setForm({ ...form, holder: e.target.value })} />
        <Button onClick={() => { if (!form.bankName) return; add(form); setForm({ bankName: "", accountNo: "", holder: "" }); toast.success("Bank added"); }}>
          <Plus className="size-4 mr-1" />Add
        </Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Bank</TableHead><TableHead>Account #</TableHead><TableHead>Holder</TableHead><TableHead></TableHead></TableRow></TableHeader>
        <TableBody>{banks.map((b) => (
          <TableRow key={b.id}>
            <TableCell className="font-medium">{b.bankName}</TableCell>
            <TableCell>{b.accountNo}</TableCell>
            <TableCell>{b.holder}</TableCell>
            <TableCell><Button size="sm" variant="ghost" onClick={() => rm(b.id)}><Trash2 className="size-4" /></Button></TableCell>
          </TableRow>
        ))}</TableBody>
      </Table>
    </CardContent></Card>
  );
}
