import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, fmtIDR, statusTone } from "@/lib/store";
import { Plus, Send, CheckCircle2, XCircle, Trash2 } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts";
import { toast } from "sonner";

export const Route = createFileRoute("/accounting/budget")({
  head: () => ({ meta: [{ title: "Budget (RKAS) — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const lines = useStore((s) => s.budgetLines);
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const addBudget = useStore((s) => s.addBudgetLine);
  const submitBudget = useStore((s) => s.submitBudget);
  const approveBudget = useStore((s) => s.approveBudget);
  const rejectBudget = useStore((s) => s.rejectBudget);
  const removeBudget = useStore((s) => s.removeBudgetLine);
  const role = useStore((s) => s.role);
  const log = useStore((s) => s.logActivity);

  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ year, accountCode: "", category: "Operasional", description: "", planned: 0 });

  // Compute actual from journal per account
  const actualByAccount = useMemo(() => {
    const m: Record<string, number> = {};
    journal.filter((j) => j.status === "Posted").forEach((j) => {
      j.lines.forEach((l) => {
        const acc = accounts.find((a) => a.code === l.accountCode);
        if (!acc) return;
        const v = acc.type === "Income" ? l.credit - l.debit : l.debit - l.credit;
        m[l.accountCode] = (m[l.accountCode] ?? 0) + v;
      });
    });
    return m;
  }, [journal, accounts]);

  const yearLines = lines.filter((l) => l.year === year);
  const totalPlanned = yearLines.filter((l) => l.status === "Approved").reduce((a, l) => a + l.planned, 0);
  const totalActual = yearLines.filter((l) => l.status === "Approved").reduce((a, l) => a + (actualByAccount[l.accountCode] ?? 0), 0);

  const chartData = yearLines.filter((l) => l.status === "Approved").map((l) => ({
    name: l.description, Plan: l.planned, Actual: actualByAccount[l.accountCode] ?? 0,
  }));

  return (
    <div>
      <PageHeader title="Budget (RKAS)" description="Rencana Kerja Anggaran Sekolah dengan workflow approval & realisasi otomatis dari jurnal"
        actions={<>
          <Select value={year} onValueChange={setYear}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>{["2024", "2025", "2026", "2027"].map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
          </Select>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4" /> Tambah Line</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Budget Line Baru</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Tahun</Label><Input value={f.year} onChange={(e) => setF({ ...f, year: e.target.value })} /></div>
                <div><Label>Kategori</Label><Input value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /></div>
                <div className="col-span-2"><Label>Account</Label>
                  <Select value={f.accountCode} onValueChange={(v) => setF({ ...f, accountCode: v })}>
                    <SelectTrigger><SelectValue placeholder="Pilih akun" /></SelectTrigger>
                    <SelectContent>{accounts.filter((a) => a.type === "Expense" || a.type === "Income").map((a) => <SelectItem key={a.code} value={a.code}>{a.code} — {a.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="col-span-2"><Label>Deskripsi</Label><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
                <div className="col-span-2"><Label>Planned (Rp)</Label><Input type="number" value={f.planned} onChange={(e) => setF({ ...f, planned: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={() => { if (!f.accountCode || !f.planned) return toast.error("Akun & nominal wajib"); addBudget(f); log("Created budget line", f.description, "Budget"); setOpen(false); toast.success("Budget line dibuat sebagai Draft"); }}>Simpan</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </>}
      />

      <div className="grid grid-cols-3 gap-4 mb-6">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Total Planned ({year})</div><div className="text-2xl font-semibold mt-1 text-primary">{fmtIDR(totalPlanned)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Total Realisasi</div><div className="text-2xl font-semibold mt-1">{fmtIDR(totalActual)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Serapan</div><div className="text-2xl font-semibold mt-1">{totalPlanned ? Math.round((totalActual / totalPlanned) * 100) : 0}%</div></CardContent></Card>
      </div>

      <Card className="mb-6"><CardContent className="p-6 h-72">
        <ResponsiveContainer><BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" fontSize={11} />
          <YAxis fontSize={11} tickFormatter={(v) => `${v / 1_000_000}M`} />
          <Tooltip formatter={(v: number) => fmtIDR(v)} />
          <Legend />
          <Bar dataKey="Plan" fill="oklch(0.42 0.18 270)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="Actual" fill="oklch(0.62 0.16 155)" radius={[4, 4, 0, 0]} />
        </BarChart></ResponsiveContainer>
      </CardContent></Card>

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>Kategori</TableHead><TableHead>Akun</TableHead><TableHead>Deskripsi</TableHead><TableHead className="text-right">Plan</TableHead><TableHead className="text-right">Actual</TableHead><TableHead className="w-40">Progress</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {yearLines.map((l) => {
              const actual = actualByAccount[l.accountCode] ?? 0;
              const pct = l.planned ? (actual / l.planned) * 100 : 0;
              const acc = accounts.find((a) => a.code === l.accountCode);
              return (
                <TableRow key={l.id}>
                  <TableCell><Badge variant="secondary">{l.category}</Badge></TableCell>
                  <TableCell className="font-mono text-xs">{l.accountCode} {acc?.name}</TableCell>
                  <TableCell>{l.description}</TableCell>
                  <TableCell className="text-right">{fmtIDR(l.planned)}</TableCell>
                  <TableCell className="text-right">{fmtIDR(actual)}</TableCell>
                  <TableCell><Progress value={Math.min(pct, 100)} className={`h-2 ${pct > 100 ? "[&>div]:bg-destructive" : ""}`} /><div className="text-[10px] text-muted-foreground mt-0.5">{Math.round(pct)}%</div></TableCell>
                  <TableCell><Badge className={statusTone(l.status)}>{l.status}</Badge></TableCell>
                  <TableCell><div className="flex gap-1">
                    {l.status === "Draft" && <Button size="sm" variant="outline" onClick={() => { submitBudget(l.id); log("Submitted budget", l.description, "Budget"); }}><Send className="size-3" /></Button>}
                    {l.status === "Submitted" && role === "Administrator" && <>
                      <Button size="sm" onClick={() => { approveBudget(l.id); log("Approved budget", l.description, "Budget"); }}><CheckCircle2 className="size-3" /></Button>
                      <Button size="sm" variant="destructive" onClick={() => rejectBudget(l.id)}><XCircle className="size-3" /></Button>
                    </>}
                    {l.status === "Draft" && <Button size="sm" variant="ghost" onClick={() => removeBudget(l.id)}><Trash2 className="size-3" /></Button>}
                  </div></TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
