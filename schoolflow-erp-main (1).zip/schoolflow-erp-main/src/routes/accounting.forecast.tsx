import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useStore, fmtIDR, outstanding } from "@/lib/store";
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ReferenceLine } from "recharts";
import { TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/accounting/forecast")({
  head: () => ({ meta: [{ title: "Cash Forecast — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const bills = useStore((s) => s.bills);
  const employees = useStore((s) => s.employees);
  const budgetLines = useStore((s) => s.budgetLines);

  const data = useMemo(() => {
    // Opening cash
    const open = (accounts.find((a) => a.code === "1100")?.openingBalance ?? 0) + (accounts.find((a) => a.code === "1200")?.openingBalance ?? 0);
    const flow = journal.reduce((acc, j) => {
      j.lines.forEach((l) => {
        if (l.accountCode === "1100" || l.accountCode === "1200") acc += l.debit - l.credit;
      });
      return acc;
    }, 0);
    const currentCash = open + flow;

    // Project 6 months forward
    const months: { label: string; inflow: number; outflow: number; net: number; ending: number }[] = [];
    let running = currentCash;
    const monthlyPayroll = employees.filter((e) => e.active).reduce((a, e) => a + e.baseSalary + e.allowance, 0);
    const monthlyOpex = (budgetLines.filter((b) => b.accountCode === "5100" && b.status === "Approved").reduce((a, b) => a + b.planned, 0)) / 12
      + (budgetLines.filter((b) => b.accountCode === "5300" && b.status === "Approved").reduce((a, b) => a + b.planned, 0)) / 12;

    for (let i = 0; i < 6; i++) {
      const d = new Date();
      d.setMonth(d.getMonth() + i);
      const period = d.toISOString().slice(0, 7);
      // Expected inflow = outstanding bills due in/before this month + recurring tuition (estimated)
      const expectedAR = i === 0
        ? bills.filter((b) => outstanding(b) > 0 && b.dueDate && b.dueDate.slice(0, 7) <= period).reduce((a, b) => a + outstanding(b), 0) * 0.85
        : (budgetLines.find((b) => b.accountCode === "4100" && b.status === "Approved")?.planned ?? 960000000) / 12 * 0.92;
      const outflow = monthlyPayroll + monthlyOpex;
      const net = expectedAR - outflow;
      running += net;
      months.push({ label: d.toLocaleDateString("id-ID", { month: "short", year: "2-digit" }), inflow: Math.round(expectedAR), outflow: Math.round(outflow), net: Math.round(net), ending: Math.round(running) });
    }
    return { currentCash, months, monthlyPayroll, monthlyOpex };
  }, [accounts, journal, bills, employees, budgetLines]);

  const criticalMonth = data.months.find((m) => m.ending < data.monthlyPayroll);

  return (
    <div>
      <PageHeader title="Cash Flow Forecast" description="Proyeksi arus kas 6 bulan ke depan berdasarkan AR outstanding, target SPP, payroll & RKAS" />

      <div className="grid grid-cols-4 gap-4 mb-6">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Cash Position Saat Ini</div><div className="text-2xl font-semibold mt-1 text-primary">{fmtIDR(data.currentCash)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><TrendingUp className="size-3 text-success" /> Avg Inflow / Bulan</div><div className="text-2xl font-semibold mt-1">{fmtIDR(Math.round(data.months.reduce((a, m) => a + m.inflow, 0) / 6))}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><TrendingDown className="size-3 text-destructive" /> Avg Outflow / Bulan</div><div className="text-2xl font-semibold mt-1">{fmtIDR(Math.round(data.months.reduce((a, m) => a + m.outflow, 0) / 6))}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Proyeksi Akhir 6 Bln</div><div className={`text-2xl font-semibold mt-1 ${data.months[5].ending < 0 ? "text-destructive" : "text-success"}`}>{fmtIDR(data.months[5].ending)}</div></CardContent></Card>
      </div>

      {criticalMonth && (
        <Card className="mb-6 border-destructive/40 bg-destructive/5"><CardContent className="p-4 flex items-center gap-3">
          <AlertTriangle className="size-5 text-destructive" />
          <div><div className="font-semibold text-destructive">Cash Warning</div><div className="text-sm">Saldo akhir bulan <strong>{criticalMonth.label}</strong> diperkirakan {fmtIDR(criticalMonth.ending)}, di bawah komitmen payroll bulanan.</div></div>
        </CardContent></Card>
      )}

      <Card className="mb-6">
        <CardHeader><CardTitle>Forecast Chart</CardTitle><CardDescription>Bars = inflow/outflow per bulan · Line = saldo akhir kumulatif</CardDescription></CardHeader>
        <CardContent className="h-80">
          <ResponsiveContainer><ComposedChart data={data.months}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="label" fontSize={12} />
            <YAxis fontSize={11} tickFormatter={(v) => `${v / 1_000_000}M`} />
            <Tooltip formatter={(v: number) => fmtIDR(v)} />
            <Legend />
            <ReferenceLine y={0} stroke="hsl(var(--destructive))" />
            <Bar dataKey="inflow" name="Inflow" fill="oklch(0.62 0.16 155)" radius={[4, 4, 0, 0]} />
            <Bar dataKey="outflow" name="Outflow" fill="oklch(0.58 0.22 27)" radius={[4, 4, 0, 0]} />
            <Line type="monotone" dataKey="ending" name="Ending Cash" stroke="oklch(0.42 0.18 270)" strokeWidth={3} dot={{ r: 5 }} />
          </ComposedChart></ResponsiveContainer>
        </CardContent>
      </Card>

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>Bulan</TableHead><TableHead className="text-right">Expected Inflow</TableHead><TableHead className="text-right">Outflow</TableHead><TableHead className="text-right">Net</TableHead><TableHead className="text-right">Ending Cash</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
          <TableBody>
            {data.months.map((m, i) => (
              <TableRow key={i}>
                <TableCell className="font-medium">{m.label}</TableCell>
                <TableCell className="text-right text-success">{fmtIDR(m.inflow)}</TableCell>
                <TableCell className="text-right text-destructive">({fmtIDR(m.outflow)})</TableCell>
                <TableCell className={`text-right font-semibold ${m.net < 0 ? "text-destructive" : "text-success"}`}>{fmtIDR(m.net)}</TableCell>
                <TableCell className="text-right font-bold">{fmtIDR(m.ending)}</TableCell>
                <TableCell>{m.ending < 0 ? <Badge variant="destructive">Defisit</Badge> : m.ending < data.monthlyPayroll ? <Badge className="bg-chart-3/15 text-chart-3">Hati-hati</Badge> : <Badge className="bg-success/15 text-success">Sehat</Badge>}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
