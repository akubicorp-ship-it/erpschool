import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, exportCSV } from "@/lib/store";
import { Download, History } from "lucide-react";

export const Route = createFileRoute("/governance/audit")({
  head: () => ({ meta: [{ title: "Audit Trail — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const activity = useStore((s) => s.activity);
  const [q, setQ] = useState("");
  const [module, setModule] = useState<string>("all");
  const [role, setRole] = useState<string>("all");

  const modules = useMemo(() => Array.from(new Set(activity.map((a) => a.module ?? "Other"))), [activity]);

  const filtered = activity.filter((a) =>
    (module === "all" || (a.module ?? "Other") === module) &&
    (role === "all" || a.role === role) &&
    (q === "" || (a.user + a.action + (a.detail ?? "")).toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <div>
      <PageHeader title="Audit Trail" description="Log semua aktivitas user lintas modul untuk keperluan kepatuhan & audit"
        actions={<Button variant="outline" onClick={() => exportCSV("audit-trail.csv", filtered.map((a) => ({ Time: new Date(a.at).toLocaleString(), User: a.user, Role: a.role, Module: a.module ?? "", Action: a.action, Detail: a.detail ?? "" })))}><Download className="size-4" /> Export CSV</Button>}
      />

      <Card className="mb-6"><CardContent className="p-4">
        <div className="grid grid-cols-4 gap-3">
          <div><Label>Pencarian</Label><Input placeholder="User, action, detail…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <div><Label>Modul</Label>
            <Select value={module} onValueChange={setModule}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="all">Semua Modul</SelectItem>{modules.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="all">Semua Role</SelectItem><SelectItem value="Administrator">Administrator</SelectItem><SelectItem value="Accounting">Accounting</SelectItem><SelectItem value="Cashier">Cashier</SelectItem></SelectContent>
            </Select>
          </div>
          <div className="flex items-end"><div className="text-sm text-muted-foreground"><History className="size-4 inline mr-1" /> {filtered.length} log entries</div></div>
        </div>
      </CardContent></Card>

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>Time</TableHead><TableHead>User</TableHead><TableHead>Role</TableHead><TableHead>Module</TableHead><TableHead>Action</TableHead><TableHead>Detail</TableHead></TableRow></TableHeader>
          <TableBody>
            {filtered.length === 0 ? <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">Tidak ada log sesuai filter.</TableCell></TableRow> :
              filtered.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="text-xs whitespace-nowrap">{new Date(a.at).toLocaleString()}</TableCell>
                  <TableCell className="font-medium">{a.user}</TableCell>
                  <TableCell><Badge variant="secondary">{a.role}</Badge></TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{a.module ?? "Other"}</Badge></TableCell>
                  <TableCell className="text-sm">{a.action}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{a.detail ?? "—"}</TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
