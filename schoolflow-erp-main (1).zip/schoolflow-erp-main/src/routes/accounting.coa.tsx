import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useStore, fmtIDR } from "@/lib/store";

export const Route = createFileRoute("/accounting/coa")({
  head: () => ({ meta: [{ title: "Chart of Accounts — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><COA /></RoleGuard>,
});

const typeColor: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  Asset: "default",
  Liability: "destructive",
  Equity: "secondary",
  Income: "default",
  Expense: "outline",
};

function COA() {
  const accounts = useStore((s) => s.accounts);
  const grouped = accounts.reduce<Record<string, typeof accounts>>((acc, a) => {
    (acc[a.type] ||= []).push(a);
    return acc;
  }, {});

  return (
    <div>
      <PageHeader title="Chart of Accounts" description="Standardized account structure for the school" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Object.entries(grouped).map(([type, list]) => (
          <Card key={type}><CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">{type}</h3>
              <Badge variant={typeColor[type]}>{list.length}</Badge>
            </div>
            <Table>
              <TableHeader><TableRow><TableHead className="w-20">Code</TableHead><TableHead>Name</TableHead><TableHead className="text-right">Opening</TableHead></TableRow></TableHeader>
              <TableBody>
                {list.map((a) => (
                  <TableRow key={a.code}>
                    <TableCell className="font-mono text-sm">{a.code}</TableCell>
                    <TableCell>{a.name}</TableCell>
                    <TableCell className="text-right">{a.openingBalance ? fmtIDR(a.openingBalance) : "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        ))}
      </div>
    </div>
  );
}
