import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, fmtIDR, billStatus, outstanding, exportCSV } from "@/lib/store";
import { Download, Printer } from "lucide-react";

export const Route = createFileRoute("/accounting/statement")({
  head: () => ({ meta: [{ title: "Student Statement — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Cashier", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const bills = useStore((s) => s.bills);
  const payments = useStore((s) => s.payments);
  const feeTypes = useStore((s) => s.feeTypes);

  const [studentId, setStudentId] = useState(students[0]?.id ?? "");

  const data = useMemo(() => {
    const student = students.find((s) => s.id === studentId);
    if (!student) return null;
    const cls = classes.find((c) => c.id === student.classId);
    const myBills = bills.filter((b) => b.studentId === studentId).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const myPayments = payments.filter((p) => p.studentId === studentId).sort((a, b) => a.date.localeCompare(b.date));
    type Txn = { date: string; type: "Bill" | "Payment"; ref: string; description: string; debit: number; credit: number };
    const txns: Txn[] = [];
    myBills.forEach((b) => {
      const f = feeTypes.find((x) => x.id === b.feeTypeId);
      txns.push({ date: b.createdAt, type: "Bill", ref: b.id.slice(0, 6).toUpperCase(), description: `${f?.name} - ${b.period}`, debit: b.amount, credit: 0 });
    });
    myPayments.forEach((p) => txns.push({ date: p.date, type: "Payment", ref: p.receiptNo, description: `${p.method} payment`, debit: 0, credit: p.total }));
    txns.sort((a, b) => a.date.localeCompare(b.date));
    let bal = 0;
    const rows = txns.map((t) => { bal += t.debit - t.credit; return { ...t, balance: bal }; });
    const totalBilled = myBills.reduce((a, b) => a + b.amount, 0);
    const totalPaid = myBills.reduce((a, b) => a + b.paid, 0);
    return { student, cls, myBills, myPayments, rows, totalBilled, totalPaid, outstanding: totalBilled - totalPaid };
  }, [studentId, students, classes, bills, payments, feeTypes]);

  if (!data) return <div>No data</div>;

  return (
    <div>
      <PageHeader title="Student Statement of Account" description="Rekening koran per siswa — semua tagihan & pembayaran dalam satu halaman"
        actions={<>
          <Button variant="outline" onClick={() => exportCSV(`statement-${data.student.nis}.csv`, data.rows)}><Download className="size-4" /> CSV</Button>
          <Button onClick={() => window.print()}><Printer className="size-4" /> Print</Button>
        </>}
      />

      <Card className="mb-6"><CardContent className="p-4">
        <div className="flex items-end gap-3">
          <div className="flex-1 max-w-md"><Label>Pilih Siswa</Label>
            <Select value={studentId} onValueChange={setStudentId}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{students.map((s) => { const c = classes.find((x) => x.id === s.classId); return <SelectItem key={s.id} value={s.id}>{s.nis} — {s.name} ({c?.name})</SelectItem>; })}</SelectContent>
            </Select>
          </div>
        </div>
      </CardContent></Card>

      <Card className="mb-6"><CardContent className="p-6">
        <div className="grid grid-cols-2 gap-6 mb-4">
          <div>
            <div className="text-xs text-muted-foreground">Siswa</div>
            <div className="text-lg font-semibold">{data.student.name}</div>
            <div className="text-sm text-muted-foreground">NIS: {data.student.nis} · {data.cls?.name}</div>
            <div className="text-sm">Wali: {data.student.parentName} ({data.student.contact})</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted-foreground">Saldo Outstanding</div>
            <div className={`text-3xl font-bold ${data.outstanding > 0 ? "text-destructive" : "text-success"}`}>{fmtIDR(data.outstanding)}</div>
            <div className="text-xs text-muted-foreground mt-1">Total ditagihkan: {fmtIDR(data.totalBilled)} · dibayar: {fmtIDR(data.totalPaid)}</div>
          </div>
        </div>
      </CardContent></Card>

      <Card className="mb-6">
        <CardHeader><CardTitle>Outstanding Bills</CardTitle></CardHeader>
        <CardContent className="p-6 pt-0">
          <Table>
            <TableHeader><TableRow><TableHead>Jenis</TableHead><TableHead>Periode</TableHead><TableHead className="text-right">Tagihan</TableHead><TableHead className="text-right">Dibayar</TableHead><TableHead className="text-right">Sisa</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
            <TableBody>
              {data.myBills.map((b) => { const f = feeTypes.find((x) => x.id === b.feeTypeId); const st = billStatus(b); return (
                <TableRow key={b.id}>
                  <TableCell>{f?.name}</TableCell>
                  <TableCell>{b.period}</TableCell>
                  <TableCell className="text-right">{fmtIDR(b.amount)}</TableCell>
                  <TableCell className="text-right">{fmtIDR(b.paid)}</TableCell>
                  <TableCell className="text-right font-semibold">{fmtIDR(outstanding(b))}</TableCell>
                  <TableCell><Badge className={st === "Paid" ? "bg-success/15 text-success" : st === "Partially Paid" ? "bg-chart-3/15 text-chart-3" : "bg-destructive/15 text-destructive"}>{st}</Badge></TableCell>
                </TableRow>
              ); })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Transaction Ledger</CardTitle></CardHeader>
        <CardContent className="p-6 pt-0">
          <Table>
            <TableHeader><TableRow><TableHead>Tanggal</TableHead><TableHead>Jenis</TableHead><TableHead>Ref</TableHead><TableHead>Deskripsi</TableHead><TableHead className="text-right">Debit</TableHead><TableHead className="text-right">Credit</TableHead><TableHead className="text-right">Balance</TableHead></TableRow></TableHeader>
            <TableBody>
              {data.rows.map((r, i) => (
                <TableRow key={i}>
                  <TableCell className="text-xs">{new Date(r.date).toLocaleDateString()}</TableCell>
                  <TableCell><Badge variant={r.type === "Bill" ? "outline" : "secondary"}>{r.type}</Badge></TableCell>
                  <TableCell className="font-mono text-xs">{r.ref}</TableCell>
                  <TableCell className="text-sm">{r.description}</TableCell>
                  <TableCell className="text-right">{r.debit ? fmtIDR(r.debit) : "-"}</TableCell>
                  <TableCell className="text-right">{r.credit ? fmtIDR(r.credit) : "-"}</TableCell>
                  <TableCell className="text-right font-semibold">{fmtIDR(r.balance)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
