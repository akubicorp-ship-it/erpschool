import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, fmtIDR } from "@/lib/store";
import { Plus, Trash2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/purchasing/vendors")({
  head: () => ({ meta: [{ title: "Vendors & Items — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator"]}><Page /></RoleGuard>,
});

function Page() {
  return (
    <div>
      <PageHeader title="Vendors & Items" description="Daftar supplier dan item gudang untuk procurement" />
      <Tabs defaultValue="vendors">
        <TabsList className="mb-4">
          <TabsTrigger value="vendors">Vendors</TabsTrigger>
          <TabsTrigger value="items">Items / Stock</TabsTrigger>
        </TabsList>
        <TabsContent value="vendors"><VendorTab /></TabsContent>
        <TabsContent value="items"><ItemTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function VendorTab() {
  const vendors = useStore((s) => s.vendors);
  const addVendor = useStore((s) => s.addVendor);
  const removeVendor = useStore((s) => s.removeVendor);
  const log = useStore((s) => s.logActivity);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ code: "", name: "", contact: "", address: "", taxId: "" });

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between mb-4">
          <div className="text-sm text-muted-foreground">{vendors.length} vendor terdaftar</div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4" /> Tambah Vendor</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Vendor Baru</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Kode</Label><Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
                <div><Label>NPWP</Label><Input value={f.taxId} onChange={(e) => setF({ ...f, taxId: e.target.value })} /></div>
                <div className="col-span-2"><Label>Nama</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
                <div><Label>Kontak</Label><Input value={f.contact} onChange={(e) => setF({ ...f, contact: e.target.value })} /></div>
                <div><Label>Alamat</Label><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>
              </div>
              <DialogFooter>
                <Button onClick={() => {
                  if (!f.name || !f.code) return toast.error("Kode & nama wajib");
                  addVendor(f); log("Created vendor", f.name, "Procurement"); setOpen(false); setF({ code: "", name: "", contact: "", address: "", taxId: "" });
                  toast.success("Vendor ditambahkan");
                }}>Simpan</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <Table>
          <TableHeader><TableRow><TableHead>Kode</TableHead><TableHead>Nama</TableHead><TableHead>Kontak</TableHead><TableHead>NPWP</TableHead><TableHead>Alamat</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {vendors.map((v) => (
              <TableRow key={v.id}>
                <TableCell className="font-mono text-xs">{v.code}</TableCell>
                <TableCell className="font-medium">{v.name}</TableCell>
                <TableCell>{v.contact}</TableCell>
                <TableCell className="font-mono text-xs">{v.taxId ?? "-"}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{v.address}</TableCell>
                <TableCell><Button size="icon" variant="ghost" onClick={() => { removeVendor(v.id); toast.success("Vendor dihapus"); }}><Trash2 className="size-4" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function ItemTab() {
  const items = useStore((s) => s.items);
  const addItem = useStore((s) => s.addItem);
  const removeItem = useStore((s) => s.removeItem);
  const log = useStore((s) => s.logActivity);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ code: "", name: "", unit: "Pcs", category: "ATK", stock: 0, avgCost: 0 });
  const totalValue = items.reduce((a, i) => a + i.stock * i.avgCost, 0);
  const lowStock = items.filter((i) => i.stock < 20).length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Total Items</div><div className="text-2xl font-semibold mt-1">{items.length}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Nilai Persediaan</div><div className="text-2xl font-semibold mt-1">{fmtIDR(totalValue)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1">{lowStock > 0 && <AlertTriangle className="size-3 text-destructive" />} Low Stock (&lt;20)</div><div className={`text-2xl font-semibold mt-1 ${lowStock > 0 ? "text-destructive" : ""}`}>{lowStock}</div></CardContent></Card>
      </div>
      <Card><CardContent className="p-6">
        <div className="flex justify-between mb-4">
          <div className="text-sm text-muted-foreground">{items.length} item aktif</div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4" /> Tambah Item</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Item Baru</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Kode</Label><Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
                <div><Label>Nama</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
                <div><Label>Satuan</Label><Input value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} /></div>
                <div><Label>Kategori</Label><Input value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /></div>
                <div><Label>Stock Awal</Label><Input type="number" value={f.stock} onChange={(e) => setF({ ...f, stock: +e.target.value })} /></div>
                <div><Label>Harga Pokok</Label><Input type="number" value={f.avgCost} onChange={(e) => setF({ ...f, avgCost: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={() => { if (!f.code || !f.name) return toast.error("Kode & nama wajib"); addItem(f); log("Created item", f.name, "Inventory"); setOpen(false); toast.success("Item ditambahkan"); }}>Simpan</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <Table>
          <TableHeader><TableRow><TableHead>Kode</TableHead><TableHead>Nama</TableHead><TableHead>Kategori</TableHead><TableHead className="text-right">Stock</TableHead><TableHead>Satuan</TableHead><TableHead className="text-right">Avg Cost</TableHead><TableHead className="text-right">Nilai</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {items.map((i) => (
              <TableRow key={i.id}>
                <TableCell className="font-mono text-xs">{i.code}</TableCell>
                <TableCell className="font-medium">{i.name}</TableCell>
                <TableCell><Badge variant="secondary">{i.category}</Badge></TableCell>
                <TableCell className={`text-right font-mono ${i.stock < 20 ? "text-destructive font-semibold" : ""}`}>{i.stock}</TableCell>
                <TableCell>{i.unit}</TableCell>
                <TableCell className="text-right">{fmtIDR(i.avgCost)}</TableCell>
                <TableCell className="text-right font-semibold">{fmtIDR(i.stock * i.avgCost)}</TableCell>
                <TableCell><Button size="icon" variant="ghost" onClick={() => removeItem(i.id)}><Trash2 className="size-4" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
