import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useStore, fmtIDR } from "@/lib/store";
import { Plus, Trash2, Users2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/hr/employees")({
  head: () => ({ meta: [{ title: "Employees — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator"]}><Page /></RoleGuard>,
});

function Page() {
  const employees = useStore((s) => s.employees);
  const addEmployee = useStore((s) => s.addEmployee);
  const removeEmployee = useStore((s) => s.removeEmployee);
  const log = useStore((s) => s.logActivity);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ nip: "", name: "", position: "", department: "Akademik", bankAccount: "", baseSalary: 0, allowance: 0, joinDate: new Date().toISOString().slice(0, 10), active: true });

  const totalPayroll = employees.filter((e) => e.active).reduce((a, e) => a + e.baseSalary + e.allowance, 0);
  const depts = [...new Set(employees.map((e) => e.department))];

  return (
    <div>
      <PageHeader title="Employees" description="Master pegawai sekolah — basis perhitungan payroll bulanan"
        actions={<Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="size-4" /> Tambah Pegawai</Button></DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>Pegawai Baru</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>NIP</Label><Input value={f.nip} onChange={(e) => setF({ ...f, nip: e.target.value })} /></div>
              <div><Label>Nama</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
              <div><Label>Posisi</Label><Input value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} /></div>
              <div><Label>Departemen</Label><Input value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })} /></div>
              <div><Label>Rekening</Label><Input value={f.bankAccount} onChange={(e) => setF({ ...f, bankAccount: e.target.value })} /></div>
              <div><Label>Tanggal Masuk</Label><Input type="date" value={f.joinDate} onChange={(e) => setF({ ...f, joinDate: e.target.value })} /></div>
              <div><Label>Gaji Pokok</Label><Input type="number" value={f.baseSalary} onChange={(e) => setF({ ...f, baseSalary: +e.target.value })} /></div>
              <div><Label>Tunjangan</Label><Input type="number" value={f.allowance} onChange={(e) => setF({ ...f, allowance: +e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={() => { if (!f.name || !f.nip) return toast.error("NIP & Nama wajib"); addEmployee(f); log("Added employee", f.name, "HR"); setOpen(false); toast.success("Pegawai ditambahkan"); }}>Simpan</Button></DialogFooter>
          </DialogContent>
        </Dialog>}
      />

      <div className="grid grid-cols-3 gap-4 mb-6">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Total Pegawai Aktif</div><div className="text-2xl font-semibold mt-1">{employees.filter((e) => e.active).length}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Departemen</div><div className="text-2xl font-semibold mt-1">{depts.length}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Komitmen Payroll / Bulan</div><div className="text-2xl font-semibold mt-1 text-primary">{fmtIDR(totalPayroll)}</div></CardContent></Card>
      </div>

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>NIP</TableHead><TableHead>Nama</TableHead><TableHead>Posisi</TableHead><TableHead>Departemen</TableHead><TableHead>Rekening</TableHead><TableHead className="text-right">Gaji Pokok</TableHead><TableHead className="text-right">Tunjangan</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {employees.map((e) => (
              <TableRow key={e.id}>
                <TableCell className="font-mono text-xs">{e.nip}</TableCell>
                <TableCell className="font-medium">{e.name}</TableCell>
                <TableCell>{e.position}</TableCell>
                <TableCell><Badge variant="secondary">{e.department}</Badge></TableCell>
                <TableCell className="text-xs">{e.bankAccount}</TableCell>
                <TableCell className="text-right">{fmtIDR(e.baseSalary)}</TableCell>
                <TableCell className="text-right">{fmtIDR(e.allowance)}</TableCell>
                <TableCell>{e.active ? <Badge className="bg-success/15 text-success">Aktif</Badge> : <Badge variant="secondary">Non-Aktif</Badge>}</TableCell>
                <TableCell><Button size="icon" variant="ghost" onClick={() => removeEmployee(e.id)}><Trash2 className="size-4" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
