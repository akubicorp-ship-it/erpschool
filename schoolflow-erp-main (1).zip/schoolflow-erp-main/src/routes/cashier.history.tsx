import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useStore, fmtIDR, exportCSV, type Payment } from "@/lib/store";
import { FileSpreadsheet, Receipt as ReceiptIcon } from "lucide-react";
import { ReceiptDialog } from "./cashier.index";

export const Route = createFileRoute("/cashier/history")({
  head: () => ({ meta: [{ title: "Payment History — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Cashier"]}><History /></RoleGuard>,
});

function History() {
  const payments = useStore((s) => s.payments);
  const students = useStore((s) => s.students);
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Payment | null>(null);

  const filtered = payments.filter((p) => {
    const st = students.find((s) => s.id === p.studentId);
    return q === "" || st?.name.toLowerCase().includes(q.toLowerCase()) || p.receiptNo.includes(q);
  });

  return (
    <div>
      <PageHeader
        title="Payment History"
        description="All cashier transactions"
        actions={
          <Button variant="outline" onClick={() => exportCSV("payments.csv", filtered.map((p) => ({
            Receipt: p.receiptNo,
            Date: new Date(p.date).toLocaleString(),
            Student: students.find((s) => s.id === p.studentId)?.name ?? "",
            Method: p.method,
            Total: p.total,
            Cashier: p.cashier,
          })))}>
            <FileSpreadsheet className="size-4 mr-1" />Export
          </Button>
        }
      />
      <Card><CardContent className="p-5">
        <Input placeholder="Search by name or receipt #..." value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs mb-4" />
        <Table>
          <TableHeader><TableRow>
            <TableHead>Receipt #</TableHead><TableHead>Date</TableHead><TableHead>Student</TableHead>
            <TableHead>Method</TableHead><TableHead className="text-right">Total</TableHead>
            <TableHead>Cashier</TableHead><TableHead></TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {filtered.map((p) => (
              <TableRow key={p.id}>
                <TableCell className="font-mono text-sm">{p.receiptNo}</TableCell>
                <TableCell>{new Date(p.date).toLocaleString()}</TableCell>
                <TableCell>{students.find((s) => s.id === p.studentId)?.name}</TableCell>
                <TableCell><Badge variant="secondary">{p.method}</Badge></TableCell>
                <TableCell className="text-right font-medium">{fmtIDR(p.total)}</TableCell>
                <TableCell>{p.cashier}</TableCell>
                <TableCell>
                  <Button size="sm" variant="ghost" onClick={() => setSelected(p)}>
                    <ReceiptIcon className="size-4 mr-1" />Receipt
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No payments yet</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent></Card>
      <ReceiptDialog payment={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
