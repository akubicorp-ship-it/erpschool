import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useStore, fmtIDR, statusTone } from "@/lib/store";
import { Banknote, Send, CheckCircle2, XCircle, FileText, Printer } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/hr/payroll")({
  head: () => ({ meta: [{ title: "Payroll Runs — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const runs = useStore((s) => s.payrollRuns);
  const employees = useStore((s) => s.employees);
  const createPayrollRun = useStore((s) => s.createPayrollRun);
  const submitPayroll = useStore((s) => s.submitPayroll);
  const approvePayroll = useStore((s) => s.approvePayroll);
  const rejectPayroll = useStore((s) => s.rejectPayroll);
  const log = useStore((s) => s.logActivity);
  const role = useStore((s) => s.role);

  const [open, setOpen] = useState(false);
  const [period, setPeriod] = useState(new Date().toISOString().slice(0, 7));
  const [pphRate, setPphRate] = useState(5);

  const [slipFor, setSlipFor] = useState<{ runId: string; employeeId: string } | null>(null);

  function generate() {
    if (runs.some((r) => r.period === period && r.status !== "Rejected")) return toast.error(`Run untuk ${period} sudah ada`);
    const r = createPayrollRun({ period, deductionRate: pphRate / 100 });
    log("Generated payroll run", r.runNo, "Payroll", r.id);
    toast.success(`Payroll ${r.runNo} dibuat sebagai Draft`);
    setOpen(false);
  }

  return (
    <div>
      <PageHeader title="Payroll Runs" description="Generate gaji bulanan, approval, auto-post ke jurnal (DR Beban Gaji / CR Bank & Hutang Pajak)"
        actions={<Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Banknote className="size-4" /> Generate Payroll</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Generate Payroll Run</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Periode</Label><Input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} /></div>
              <div><Label>PPh21 Rate (%)</Label><Input type="number" value={pphRate} onChange={(e) => setPphRate(+e.target.value)} /></div>
            </div>
            <div className="text-xs text-muted-foreground">Akan generate slip untuk {employees.filter((e) => e.active).length} pegawai aktif.</div>
            <DialogFooter><Button onClick={generate}>Generate</Button></DialogFooter>
          </DialogContent>
        </Dialog>}
      />

      <Card className="mb-6"><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>Run No</TableHead><TableHead>Periode</TableHead><TableHead>Pegawai</TableHead><TableHead className="text-right">Gross</TableHead><TableHead className="text-right">PPh21</TableHead><TableHead className="text-right">Net</TableHead><TableHead>Status</TableHead><TableHead>Workflow</TableHead></TableRow></TableHeader>
          <TableBody>
            {runs.length === 0 ? <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">Belum ada payroll run.</TableCell></TableRow> :
              runs.map((r) => {
                const gross = r.lines.reduce((a, l) => a + l.base + l.allowance, 0);
                const ded = r.lines.reduce((a, l) => a + l.deduction, 0);
                return (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono text-xs">{r.runNo}</TableCell>
                    <TableCell>{r.period}</TableCell>
                    <TableCell>{r.lines.length}</TableCell>
                    <TableCell className="text-right">{fmtIDR(gross)}</TableCell>
                    <TableCell className="text-right text-destructive">{fmtIDR(ded)}</TableCell>
                    <TableCell className="text-right font-semibold">{fmtIDR(r.total)}</TableCell>
                    <TableCell><Badge className={statusTone(r.status)}>{r.status}</Badge></TableCell>
                    <TableCell><div className="flex gap-1">
                      {r.status === "Draft" && <Button size="sm" variant="outline" onClick={() => { submitPayroll(r.id); log("Submitted payroll", r.runNo, "Payroll", r.id); }}><Send className="size-3" /> Submit</Button>}
                      {r.status === "Submitted" && role === "Administrator" && <>
                        <Button size="sm" onClick={() => { approvePayroll(r.id); log("Approved & posted payroll", r.runNo, "Payroll", r.id); toast.success("Payroll posted ke jurnal"); }}><CheckCircle2 className="size-3" /> Approve</Button>
                        <Button size="sm" variant="destructive" onClick={() => rejectPayroll(r.id)}><XCircle className="size-3" /></Button>
                      </>}
                      {r.status === "Posted" && <Badge variant="outline" className="text-xs"><FileText className="size-3 mr-1" /> Posted</Badge>}
                    </div></TableCell>
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </CardContent></Card>

      {runs.length > 0 && (
        <Card>
          <CardHeader><CardTitle>Slip Gaji — {runs[0].runNo} ({runs[0].period})</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader><TableRow><TableHead>NIP</TableHead><TableHead>Nama</TableHead><TableHead>Posisi</TableHead><TableHead className="text-right">Pokok</TableHead><TableHead className="text-right">Tunjangan</TableHead><TableHead className="text-right">PPh21</TableHead><TableHead className="text-right">Take Home</TableHead><TableHead></TableHead></TableRow></TableHeader>
              <TableBody>
                {runs[0].lines.map((l) => {
                  const e = employees.find((x) => x.id === l.employeeId);
                  return (
                    <TableRow key={l.employeeId}>
                      <TableCell className="font-mono text-xs">{e?.nip}</TableCell>
                      <TableCell className="font-medium">{e?.name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{e?.position}</TableCell>
                      <TableCell className="text-right">{fmtIDR(l.base)}</TableCell>
                      <TableCell className="text-right">{fmtIDR(l.allowance)}</TableCell>
                      <TableCell className="text-right text-destructive">{fmtIDR(l.deduction)}</TableCell>
                      <TableCell className="text-right font-semibold text-success">{fmtIDR(l.net)}</TableCell>
                      <TableCell><Button size="sm" variant="ghost" onClick={() => setSlipFor({ runId: runs[0].id, employeeId: l.employeeId })}><Printer className="size-3" /></Button></TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!slipFor} onOpenChange={(v) => !v && setSlipFor(null)}>
        <DialogContent>
          {slipFor && (() => {
            const r = runs.find((x) => x.id === slipFor.runId)!;
            const l = r.lines.find((x) => x.employeeId === slipFor.employeeId)!;
            const e = employees.find((x) => x.id === slipFor.employeeId)!;
            return (
              <div>
                <DialogHeader><DialogTitle>Slip Gaji — {r.period}</DialogTitle></DialogHeader>
                <div className="border rounded-lg p-6 space-y-3 mt-3 bg-card">
                  <div className="flex justify-between"><div><div className="font-semibold">SMP Harapan Bangsa</div><div className="text-xs text-muted-foreground">Slip Gaji {r.period}</div></div><div className="text-xs text-right"><div>Run: {r.runNo}</div><div>{new Date(r.date).toLocaleDateString()}</div></div></div>
                  <div className="border-t pt-3 grid grid-cols-2 gap-2 text-sm">
                    <div><span className="text-muted-foreground">Nama:</span> <span className="font-medium">{e.name}</span></div>
                    <div><span className="text-muted-foreground">NIP:</span> {e.nip}</div>
                    <div><span className="text-muted-foreground">Posisi:</span> {e.position}</div>
                    <div><span className="text-muted-foreground">Rekening:</span> {e.bankAccount}</div>
                  </div>
                  <div className="border-t pt-3 space-y-1 text-sm">
                    <div className="flex justify-between"><span>Gaji Pokok</span><span>{fmtIDR(l.base)}</span></div>
                    <div className="flex justify-between"><span>Tunjangan</span><span>{fmtIDR(l.allowance)}</span></div>
                    <div className="flex justify-between text-destructive"><span>PPh21</span><span>({fmtIDR(l.deduction)})</span></div>
                    <div className="flex justify-between font-semibold text-lg border-t pt-2"><span>Take Home Pay</span><span>{fmtIDR(l.net)}</span></div>
                  </div>
                </div>
                <DialogFooter><Button onClick={() => window.print()}><Printer className="size-4" /> Print</Button></DialogFooter>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
