import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useStore, fmtIDR, outstanding, billStatus, exportCSV } from "@/lib/store";
import { FileSpreadsheet, Printer } from "lucide-react";

export const Route = createFileRoute("/accounting/reports")({
  head: () => ({ meta: [{ title: "Financial Reports — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Reports /></RoleGuard>,
});

function Reports() {
  return (
    <div>
      <PageHeader
        title="Financial Reports"
        description="Balance Sheet, Income Statement, Cash Flow, and Receivables"
        actions={
          <Button variant="outline" onClick={() => window.print()}><Printer className="size-4 mr-1" />Print View</Button>
        }
      />
      <Tabs defaultValue="balance">
        <TabsList className="mb-4">
          <TabsTrigger value="balance">Balance Sheet</TabsTrigger>
          <TabsTrigger value="income">Income Statement</TabsTrigger>
          <TabsTrigger value="cashflow">Cash Flow</TabsTrigger>
          <TabsTrigger value="receivables">Receivables</TabsTrigger>
        </TabsList>
        <TabsContent value="balance"><BalanceSheet /></TabsContent>
        <TabsContent value="income"><IncomeStatement /></TabsContent>
        <TabsContent value="cashflow"><CashFlow /></TabsContent>
        <TabsContent value="receivables"><Receivables /></TabsContent>
      </Tabs>
    </div>
  );
}

function balanceFor(code: string, accounts: ReturnType<typeof useStore.getState>["accounts"], journal: ReturnType<typeof useStore.getState>["journal"]) {
  const acc = accounts.find((a) => a.code === code);
  let bal = acc?.openingBalance ?? 0;
  journal.forEach((j) => j.lines.forEach((l) => {
    if (l.accountCode === code) bal += l.debit - l.credit;
  }));
  return bal;
}

function BalanceSheet() {
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const assets = accounts.filter((a) => a.type === "Asset");
  const liab = accounts.filter((a) => a.type === "Liability");
  const equity = accounts.filter((a) => a.type === "Equity");

  const totalAssets = assets.reduce((a, x) => a + balanceFor(x.code, accounts, journal), 0);
  const totalLE = liab.concat(equity).reduce((a, x) => a + (-balanceFor(x.code, accounts, journal)), 0);

  return (
    <Card className="print-area"><CardContent className="p-6">
      <h3 className="text-center font-bold text-lg">Balance Sheet</h3>
      <p className="text-center text-sm text-muted-foreground mb-4">As of {new Date().toLocaleDateString()}</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h4 className="font-semibold mb-2">Assets</h4>
          <Table><TableBody>
            {assets.map((a) => (
              <TableRow key={a.code}><TableCell>{a.name}</TableCell><TableCell className="text-right">{fmtIDR(balanceFor(a.code, accounts, journal))}</TableCell></TableRow>
            ))}
            <TableRow className="font-bold bg-muted"><TableCell>Total Assets</TableCell><TableCell className="text-right">{fmtIDR(totalAssets)}</TableCell></TableRow>
          </TableBody></Table>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Liabilities & Equity</h4>
          <Table><TableBody>
            {liab.concat(equity).map((a) => (
              <TableRow key={a.code}><TableCell>{a.name}</TableCell><TableCell className="text-right">{fmtIDR(-balanceFor(a.code, accounts, journal))}</TableCell></TableRow>
            ))}
            <TableRow className="font-bold bg-muted"><TableCell>Total L + E</TableCell><TableCell className="text-right">{fmtIDR(totalLE)}</TableCell></TableRow>
          </TableBody></Table>
        </div>
      </div>
    </CardContent></Card>
  );
}

function IncomeStatement() {
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const income = accounts.filter((a) => a.type === "Income");
  const expense = accounts.filter((a) => a.type === "Expense");
  const totalIncome = income.reduce((a, x) => a + (-balanceFor(x.code, accounts, journal)), 0);
  const totalExpense = expense.reduce((a, x) => a + balanceFor(x.code, accounts, journal), 0);
  const net = totalIncome - totalExpense;

  return (
    <Card className="print-area"><CardContent className="p-6">
      <h3 className="text-center font-bold text-lg">Income Statement</h3>
      <p className="text-center text-sm text-muted-foreground mb-4">Period to {new Date().toLocaleDateString()}</p>
      <Table><TableBody>
        <TableRow className="bg-muted"><TableCell colSpan={2} className="font-semibold">Income</TableCell></TableRow>
        {income.map((a) => (
          <TableRow key={a.code}><TableCell className="pl-6">{a.name}</TableCell><TableCell className="text-right">{fmtIDR(-balanceFor(a.code, accounts, journal))}</TableCell></TableRow>
        ))}
        <TableRow className="font-semibold"><TableCell>Total Income</TableCell><TableCell className="text-right">{fmtIDR(totalIncome)}</TableCell></TableRow>
        <TableRow className="bg-muted"><TableCell colSpan={2} className="font-semibold">Expenses</TableCell></TableRow>
        {expense.map((a) => (
          <TableRow key={a.code}><TableCell className="pl-6">{a.name}</TableCell><TableCell className="text-right">{fmtIDR(balanceFor(a.code, accounts, journal))}</TableCell></TableRow>
        ))}
        <TableRow className="font-semibold"><TableCell>Total Expenses</TableCell><TableCell className="text-right">{fmtIDR(totalExpense)}</TableCell></TableRow>
        <TableRow className="bg-primary/10 font-bold"><TableCell>Net Income</TableCell><TableCell className="text-right">{fmtIDR(net)}</TableCell></TableRow>
      </TableBody></Table>
    </CardContent></Card>
  );
}

function CashFlow() {
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const cash = balanceFor("1100", accounts, journal);
  const bank = balanceFor("1200", accounts, journal);

  const inflows = journal.flatMap((j) => j.lines.filter((l) => (l.accountCode === "1100" || l.accountCode === "1200") && l.debit > 0).map((l) => ({ j, l })));
  const outflows = journal.flatMap((j) => j.lines.filter((l) => (l.accountCode === "1100" || l.accountCode === "1200") && l.credit > 0).map((l) => ({ j, l })));
  const totalIn = inflows.reduce((a, x) => a + x.l.debit, 0);
  const totalOut = outflows.reduce((a, x) => a + x.l.credit, 0);

  return (
    <Card className="print-area"><CardContent className="p-6">
      <h3 className="text-center font-bold text-lg">Cash Flow Statement</h3>
      <p className="text-center text-sm text-muted-foreground mb-4">As of {new Date().toLocaleDateString()}</p>
      <Table><TableBody>
        <TableRow><TableCell>Opening Cash & Bank</TableCell><TableCell className="text-right">{fmtIDR(175_000_000)}</TableCell></TableRow>
        <TableRow className="bg-success/10"><TableCell>Total Inflows</TableCell><TableCell className="text-right text-success font-semibold">+ {fmtIDR(totalIn)}</TableCell></TableRow>
        <TableRow className="bg-destructive/10"><TableCell>Total Outflows</TableCell><TableCell className="text-right text-destructive font-semibold">- {fmtIDR(totalOut)}</TableCell></TableRow>
        <TableRow className="bg-primary/10 font-bold"><TableCell>Ending Cash & Bank</TableCell><TableCell className="text-right">{fmtIDR(cash + bank)}</TableCell></TableRow>
      </TableBody></Table>
    </CardContent></Card>
  );
}

function Receivables() {
  const bills = useStore((s) => s.bills);
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const feeTypes = useStore((s) => s.feeTypes);

  const open = bills.filter((b) => outstanding(b) > 0);
  const total = open.reduce((a, b) => a + outstanding(b), 0);

  return (
    <Card className="print-area"><CardContent className="p-6">
      <div className="flex justify-between mb-4 items-end">
        <div>
          <h3 className="font-bold text-lg">Student Receivables Report</h3>
          <p className="text-sm text-muted-foreground">As of {new Date().toLocaleDateString()}</p>
        </div>
        <Button variant="outline" size="sm" className="no-print" onClick={() => exportCSV("receivables.csv", open.map((b) => ({
          Student: students.find((s) => s.id === b.studentId)?.name ?? "",
          Class: classes.find((c) => c.id === students.find((s) => s.id === b.studentId)?.classId)?.name ?? "",
          Fee: feeTypes.find((f) => f.id === b.feeTypeId)?.name ?? "",
          Period: b.period, Outstanding: outstanding(b), Status: billStatus(b),
        })))}><FileSpreadsheet className="size-4 mr-1" />Export</Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Student</TableHead><TableHead>Class</TableHead><TableHead>Fee</TableHead><TableHead>Period</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Outstanding</TableHead></TableRow></TableHeader>
        <TableBody>
          {open.map((b) => {
            const st = students.find((s) => s.id === b.studentId);
            return (
              <TableRow key={b.id}>
                <TableCell>{st?.name}</TableCell>
                <TableCell>{classes.find((c) => c.id === st?.classId)?.name}</TableCell>
                <TableCell>{feeTypes.find((f) => f.id === b.feeTypeId)?.name}</TableCell>
                <TableCell>{b.period}</TableCell>
                <TableCell><Badge variant={billStatus(b) === "Partially Paid" ? "secondary" : "destructive"}>{billStatus(b)}</Badge></TableCell>
                <TableCell className="text-right font-medium">{fmtIDR(outstanding(b))}</TableCell>
              </TableRow>
            );
          })}
          <TableRow className="bg-primary/10 font-bold"><TableCell colSpan={5}>Total Receivables</TableCell><TableCell className="text-right">{fmtIDR(total)}</TableCell></TableRow>
        </TableBody>
      </Table>
    </CardContent></Card>
  );
}
