import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useStore, fmtIDR, statusTone, type JournalLine } from "@/lib/store";
import { Plus, Trash2, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/accounting/journal")({
  head: () => ({ meta: [{ title: "General Journal — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Journal /></RoleGuard>,
});

function Journal() {
  const journal = useStore((s) => s.journal);
  const accounts = useStore((s) => s.accounts);
  const addManual = useStore((s) => s.addManualJournal);
  const approveJ = useStore((s) => s.approveJournal);
  const rejectJ = useStore((s) => s.rejectJournal);
  const role = useStore((s) => s.role);
  const log = useStore((s) => s.logActivity);

  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [desc, setDesc] = useState("");
  const [ref, setRef] = useState("");
  const [lines, setLines] = useState<JournalLine[]>([
    { accountCode: "", debit: 0, credit: 0 },
    { accountCode: "", debit: 0, credit: 0 },
  ]);

  const totalD = lines.reduce((a, l) => a + (l.debit || 0), 0);
  const totalC = lines.reduce((a, l) => a + (l.credit || 0), 0);
  const balanced = totalD === totalC && totalD > 0;

  const setLine = (i: number, patch: Partial<JournalLine>) =>
    setLines(lines.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));

  const submit = () => {
    if (!balanced) return toast.error("Debit must equal Credit and be > 0");
    if (lines.some((l) => !l.accountCode)) return toast.error("Each line needs an account");
    addManual({ date, ref: ref || `JM-${Date.now().toString().slice(-6)}`, description: desc, lines });
    toast.success("Manual journal posted");
    setOpen(false);
    setDesc(""); setRef("");
    setLines([{ accountCode: "", debit: 0, credit: 0 }, { accountCode: "", debit: 0, credit: 0 }]);
  };

  return (
    <div>
      <PageHeader
        title="General Journal"
        description="Auto-posted and manual journal entries"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4 mr-1" />Manual Entry</Button></DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader><DialogTitle>New Manual Journal</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Date</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
                <div><Label>Reference</Label><Input placeholder="optional" value={ref} onChange={(e) => setRef(e.target.value)} /></div>
              </div>
              <div><Label>Description</Label><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} /></div>
              <Table>
                <TableHeader><TableRow><TableHead>Account</TableHead><TableHead className="text-right">Debit</TableHead><TableHead className="text-right">Credit</TableHead><TableHead></TableHead></TableRow></TableHeader>
                <TableBody>
                  {lines.map((l, i) => (
                    <TableRow key={i}>
                      <TableCell>
                        <Select value={l.accountCode} onValueChange={(v) => setLine(i, { accountCode: v })}>
                          <SelectTrigger><SelectValue placeholder="Account" /></SelectTrigger>
                          <SelectContent>
                            {accounts.map((a) => <SelectItem key={a.code} value={a.code}>{a.code} — {a.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell><Input type="number" value={l.debit || ""} onChange={(e) => setLine(i, { debit: +e.target.value, credit: 0 })} className="text-right" /></TableCell>
                      <TableCell><Input type="number" value={l.credit || ""} onChange={(e) => setLine(i, { credit: +e.target.value, debit: 0 })} className="text-right" /></TableCell>
                      <TableCell>
                        <Button size="icon" variant="ghost" onClick={() => setLines(lines.filter((_, idx) => idx !== i))}>
                          <Trash2 className="size-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <Button variant="outline" size="sm" onClick={() => setLines([...lines, { accountCode: "", debit: 0, credit: 0 }])}>
                <Plus className="size-4 mr-1" />Add Line
              </Button>
              <div className="flex justify-between items-center bg-muted rounded p-3 text-sm">
                <span>Totals</span>
                <span>Debit: <b>{fmtIDR(totalD)}</b> · Credit: <b>{fmtIDR(totalC)}</b></span>
                <Badge variant={balanced ? "default" : "destructive"}>{balanced ? "Balanced" : "Unbalanced"}</Badge>
              </div>
              <DialogFooter><Button onClick={submit} disabled={!balanced}>Post Journal</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <Card><CardContent className="p-5">
        <Table>
          <TableHeader><TableRow>
            <TableHead>Date</TableHead><TableHead>Ref</TableHead><TableHead>Description</TableHead>
            <TableHead>Source</TableHead><TableHead>Status</TableHead><TableHead>Account</TableHead>
            <TableHead className="text-right">Debit</TableHead><TableHead className="text-right">Credit</TableHead>
            <TableHead></TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {journal.length === 0 && (
              <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-8">No journal entries yet. Process a payment in Cashier to see auto-posting.</TableCell></TableRow>
            )}
            {journal.map((j) => j.lines.map((l, i) => (
              <TableRow key={j.id + i}>
                {i === 0 ? (
                  <>
                    <TableCell rowSpan={j.lines.length}>{new Date(j.date).toLocaleDateString()}</TableCell>
                    <TableCell rowSpan={j.lines.length} className="font-mono text-xs">{j.ref}</TableCell>
                    <TableCell rowSpan={j.lines.length}>{j.description}</TableCell>
                    <TableCell rowSpan={j.lines.length}>
                      <Badge variant={j.source === "Auto" ? "default" : "secondary"}>{j.source}</Badge>
                      {j.module && <div className="text-[10px] text-muted-foreground mt-0.5">{j.module}</div>}
                    </TableCell>
                    <TableCell rowSpan={j.lines.length}><Badge className={statusTone(j.status)}>{j.status}</Badge></TableCell>
                  </>
                ) : null}
                <TableCell className="text-sm">{l.accountCode} — {accounts.find((a) => a.code === l.accountCode)?.name}</TableCell>
                <TableCell className="text-right">{l.debit ? fmtIDR(l.debit) : ""}</TableCell>
                <TableCell className="text-right">{l.credit ? fmtIDR(l.credit) : ""}</TableCell>
                {i === 0 ? (
                  <TableCell rowSpan={j.lines.length}>
                    {j.status === "Submitted" && role === "Administrator" && (
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" onClick={() => { approveJ(j.id); log("Approved journal", j.ref, "Journal", j.id); toast.success("Journal posted"); }}><CheckCircle2 className="size-4 text-success" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => { rejectJ(j.id); log("Rejected journal", j.ref, "Journal", j.id); }}><XCircle className="size-4 text-destructive" /></Button>
                      </div>
                    )}
                  </TableCell>
                ) : null}
              </TableRow>
            )))}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
