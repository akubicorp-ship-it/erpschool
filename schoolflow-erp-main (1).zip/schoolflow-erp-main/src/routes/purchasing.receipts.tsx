import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, fmtIDR } from "@/lib/store";
import { Package, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/purchasing/receipts")({
  head: () => ({ meta: [{ title: "Goods Receipts — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const pos = useStore((s) => s.purchaseOrders);
  const grs = useStore((s) => s.goodsReceipts);
  const vendors = useStore((s) => s.vendors);
  const items = useStore((s) => s.items);
  const receiveGoods = useStore((s) => s.receiveGoods);
  const user = useStore((s) => s.currentUser);
  const log = useStore((s) => s.logActivity);

  const [open, setOpen] = useState(false);
  const [poId, setPoId] = useState("");
  const [qty, setQty] = useState<Record<string, number>>({});

  const openPOs = pos.filter((p) => p.status === "Approved");
  const selectedPO = pos.find((p) => p.id === poId);

  function submit() {
    if (!selectedPO) return;
    const lines = Object.entries(qty).filter(([, q]) => q > 0).map(([itemId, q]) => ({ itemId, qty: q }));
    if (!lines.length) return toast.error("Isi qty yang diterima");
    const gr = receiveGoods({ poId, lines, receivedBy: user?.name ?? "System" });
    log("Goods received", gr.grNo, "Procurement", gr.id);
    toast.success(`${gr.grNo} dicatat, stock & jurnal terupdate otomatis`);
    setOpen(false); setPoId(""); setQty({});
  }

  return (
    <div>
      <PageHeader title="Goods Receipts" description="Penerimaan barang dari PO yang sudah di-approve — auto post DR Inventory / CR Hutang"
        actions={<Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Package className="size-4" /> Terima Barang</Button></DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>Goods Receipt Baru</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Pilih PO (Approved)</Label>
                <Select value={poId} onValueChange={setPoId}>
                  <SelectTrigger><SelectValue placeholder="Pilih PO" /></SelectTrigger>
                  <SelectContent>{openPOs.map((p) => { const v = vendors.find((x) => x.id === p.vendorId); return <SelectItem key={p.id} value={p.id}>{p.poNo} — {v?.name}</SelectItem>; })}</SelectContent>
                </Select>
              </div>
              {selectedPO && <Table>
                <TableHeader><TableRow><TableHead>Item</TableHead><TableHead className="text-right">Ordered</TableHead><TableHead className="text-right">Sudah Diterima</TableHead><TableHead className="w-32">Qty Terima</TableHead></TableRow></TableHeader>
                <TableBody>
                  {selectedPO.lines.map((l) => {
                    const it = items.find((x) => x.id === l.itemId);
                    const received = selectedPO.receivedQty[l.itemId] ?? 0;
                    const remain = l.qty - received;
                    return (
                      <TableRow key={l.itemId}>
                        <TableCell>{it?.name}</TableCell>
                        <TableCell className="text-right">{l.qty}</TableCell>
                        <TableCell className="text-right">{received}</TableCell>
                        <TableCell><Input type="number" max={remain} placeholder={`max ${remain}`} value={qty[l.itemId] ?? ""} onChange={(e) => setQty({ ...qty, [l.itemId]: Math.min(+e.target.value, remain) })} /></TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>}
            </div>
            <DialogFooter><Button onClick={submit} disabled={!selectedPO}><CheckCircle2 className="size-4" /> Terima & Post Jurnal</Button></DialogFooter>
          </DialogContent>
        </Dialog>}
      />

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>GR No</TableHead><TableHead>Tanggal</TableHead><TableHead>PO</TableHead><TableHead>Vendor</TableHead><TableHead className="text-right">Total Item</TableHead><TableHead>Diterima Oleh</TableHead><TableHead>Jurnal</TableHead></TableRow></TableHeader>
          <TableBody>
            {grs.length === 0 ? <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">Belum ada penerimaan barang.</TableCell></TableRow> :
              grs.map((g) => {
                const po = pos.find((p) => p.id === g.poId);
                const v = vendors.find((x) => x.id === po?.vendorId);
                const totalQty = g.lines.reduce((a, l) => a + l.qty, 0);
                return (
                  <TableRow key={g.id}>
                    <TableCell className="font-mono text-xs">{g.grNo}</TableCell>
                    <TableCell className="text-xs">{new Date(g.date).toLocaleDateString()}</TableCell>
                    <TableCell className="font-mono text-xs">{po?.poNo}</TableCell>
                    <TableCell>{v?.name}</TableCell>
                    <TableCell className="text-right">{totalQty}</TableCell>
                    <TableCell className="text-xs">{g.receivedBy}</TableCell>
                    <TableCell><Badge variant="secondary" className="text-xs">Auto-posted</Badge></TableCell>
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
