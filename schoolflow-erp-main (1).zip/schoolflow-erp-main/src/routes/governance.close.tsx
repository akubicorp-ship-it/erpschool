import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useStore, fmtIDR } from "@/lib/store";
import { Lock, Unlock, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/governance/close")({
  head: () => ({ meta: [{ title: "Period Close — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const closed = useStore((s) => s.closedPeriods);
  const journal = useStore((s) => s.journal);
  const accounts = useStore((s) => s.accounts);
  const closePeriod = useStore((s) => s.closePeriod);
  const reopenPeriod = useStore((s) => s.reopenPeriod);
  const log = useStore((s) => s.logActivity);
  const role = useStore((s) => s.role);

  const [period, setPeriod] = useState(new Date().toISOString().slice(0, 7));

  const periodJournal = journal.filter((j) => j.date.slice(0, 7) === period && j.status === "Posted");
  const pendingApproval = journal.filter((j) => j.date.slice(0, 7) === period && j.status === "Submitted").length;

  // Trial balance check for selected period
  const totals = periodJournal.reduce((acc, j) => {
    j.lines.forEach((l) => { acc.dr += l.debit; acc.cr += l.credit; });
    return acc;
  }, { dr: 0, cr: 0 });
  const balanced = Math.abs(totals.dr - totals.cr) < 0.01;
  const isClosed = closed.some((c) => c.period === period);

  function doClose() {
    if (!balanced) return toast.error("Jurnal belum balance, tidak bisa close period");
    if (pendingApproval > 0) return toast.error(`Masih ada ${pendingApproval} jurnal menunggu approval`);
    if (closePeriod(period)) { log("Closed period", period, "Governance"); toast.success(`Periode ${period} ditutup`); }
  }

  return (
    <div>
      <PageHeader title="Period Close" description="Tutup periode akuntansi agar tidak ada transaksi baru di bulan tersebut. Hanya Administrator yang bisa reopen." />

      <Card className="mb-6">
        <CardHeader><CardTitle>Pre-Close Checklist</CardTitle><CardDescription>Periode: {period}</CardDescription></CardHeader>
        <CardContent className="p-6 pt-0 space-y-4">
          <div className="flex items-end gap-3">
            <div><Label>Pilih Periode</Label><Input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} /></div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <Card className={balanced ? "border-success/40" : "border-destructive/40"}><CardContent className="p-4">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">{balanced ? <CheckCircle2 className="size-4 text-success" /> : <AlertCircle className="size-4 text-destructive" />} Trial Balance</div>
              <div className="text-lg font-semibold mt-1">{balanced ? "Balanced" : "Tidak Balance"}</div>
              <div className="text-xs text-muted-foreground">DR {fmtIDR(totals.dr)} · CR {fmtIDR(totals.cr)}</div>
            </CardContent></Card>
            <Card className={pendingApproval === 0 ? "border-success/40" : "border-chart-3/40"}><CardContent className="p-4">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">{pendingApproval === 0 ? <CheckCircle2 className="size-4 text-success" /> : <AlertCircle className="size-4 text-chart-3" />} Pending Approval</div>
              <div className="text-lg font-semibold mt-1">{pendingApproval}</div>
              <div className="text-xs text-muted-foreground">jurnal menunggu</div>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <div className="text-xs text-muted-foreground">Total Posted Journal</div>
              <div className="text-lg font-semibold mt-1">{periodJournal.length}</div>
              <div className="text-xs text-muted-foreground">entri</div>
            </CardContent></Card>
          </div>

          <div className="flex gap-2">
            {!isClosed && <Button onClick={doClose} disabled={!balanced || pendingApproval > 0}><Lock className="size-4" /> Close Period {period}</Button>}
            {isClosed && role === "Administrator" && <Button variant="outline" onClick={() => { reopenPeriod(period); log("Re-opened period", period, "Governance"); toast.success(`Periode ${period} dibuka kembali`); }}><Unlock className="size-4" /> Reopen Period</Button>}
            {isClosed && <Badge className="bg-success/15 text-success">Period Closed</Badge>}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>History — Closed Periods</CardTitle></CardHeader>
        <CardContent className="p-6 pt-0">
          {closed.length === 0 ? <div className="text-sm text-muted-foreground text-center py-6">Belum ada periode yang ditutup.</div> :
            <Table>
              <TableHeader><TableRow><TableHead>Periode</TableHead><TableHead>Closed At</TableHead><TableHead>Closed By</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
              <TableBody>
                {closed.map((c) => (
                  <TableRow key={c.period}>
                    <TableCell className="font-semibold">{c.period}</TableCell>
                    <TableCell className="text-xs">{new Date(c.closedAt).toLocaleString()}</TableCell>
                    <TableCell>{c.closedBy}</TableCell>
                    <TableCell><Badge className="bg-success/15 text-success">Closed</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>}
        </CardContent>
      </Card>
    </div>
  );
}
