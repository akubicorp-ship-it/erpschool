import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useStore, fmtIDR, statusTone, type POLine } from "@/lib/store";
import { Plus, Send, CheckCircle2, XCircle, Trash2, FileText } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/purchasing/orders")({
  head: () => ({ meta: [{ title: "Purchase Orders — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const pos = useStore((s) => s.purchaseOrders);
  const vendors = useStore((s) => s.vendors);
  const items = useStore((s) => s.items);
  const createPO = useStore((s) => s.createPO);
  const submitPO = useStore((s) => s.submitPO);
  const approvePO = useStore((s) => s.approvePO);
  const rejectPO = useStore((s) => s.rejectPO);
  const log = useStore((s) => s.logActivity);
  const role = useStore((s) => s.role);

  const [open, setOpen] = useState(false);
  const [vendorId, setVendorId] = useState("");
  const [lines, setLines] = useState<POLine[]>([{ itemId: "", qty: 1, price: 0 }]);
  const [notes, setNotes] = useState("");

  const total = lines.reduce((a, l) => a + l.qty * l.price, 0);

  function addLine() { setLines([...lines, { itemId: "", qty: 1, price: 0 }]); }
  function updateLine(i: number, p: Partial<POLine>) {
    const copy = [...lines]; copy[i] = { ...copy[i], ...p };
    if (p.itemId) { const it = items.find((x) => x.id === p.itemId); if (it && !copy[i].price) copy[i].price = it.avgCost; }
    setLines(copy);
  }
  function save() {
    if (!vendorId) return toast.error("Pilih vendor");
    const valid = lines.filter((l) => l.itemId && l.qty > 0 && l.price > 0);
    if (!valid.length) return toast.error("Tambahkan minimal 1 baris");
    const po = createPO({ vendorId, lines: valid, notes });
    log("Created PO", po.poNo, "Procurement", po.id);
    toast.success(`PO ${po.poNo} dibuat sebagai Draft`);
    setOpen(false); setVendorId(""); setLines([{ itemId: "", qty: 1, price: 0 }]); setNotes("");
  }

  const kpi = {
    draft: pos.filter((p) => p.status === "Draft").length,
    pending: pos.filter((p) => p.status === "Submitted").length,
    approved: pos.filter((p) => p.status === "Approved").length,
    closed: pos.filter((p) => p.status === "Closed").length,
  };

  return (
    <div>
      <PageHeader title="Purchase Orders" description="Workflow procurement: Draft → Submit → Approve → Goods Receipt"
        actions={<Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="size-4" /> Buat PO</Button></DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader><DialogTitle>Purchase Order Baru</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Vendor</Label>
                  <Select value={vendorId} onValueChange={setVendorId}>
                    <SelectTrigger><SelectValue placeholder="Pilih vendor" /></SelectTrigger>
                    <SelectContent>{vendors.map((v) => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Tanggal</Label><Input value={new Date().toLocaleDateString()} disabled /></div>
              </div>
              <div>
                <div className="flex justify-between mb-2"><Label>Items</Label><Button size="sm" variant="outline" onClick={addLine}><Plus className="size-3" /> Baris</Button></div>
                <Table>
                  <TableHeader><TableRow><TableHead>Item</TableHead><TableHead className="w-20">Qty</TableHead><TableHead className="w-32">Harga</TableHead><TableHead className="text-right w-32">Subtotal</TableHead><TableHead className="w-10"></TableHead></TableRow></TableHeader>
                  <TableBody>
                    {lines.map((l, i) => (
                      <TableRow key={i}>
                        <TableCell><Select value={l.itemId} onValueChange={(v) => updateLine(i, { itemId: v })}>
                          <SelectTrigger><SelectValue placeholder="Pilih item" /></SelectTrigger>
                          <SelectContent>{items.map((it) => <SelectItem key={it.id} value={it.id}>{it.name}</SelectItem>)}</SelectContent>
                        </Select></TableCell>
                        <TableCell><Input type="number" value={l.qty} onChange={(e) => updateLine(i, { qty: +e.target.value })} /></TableCell>
                        <TableCell><Input type="number" value={l.price} onChange={(e) => updateLine(i, { price: +e.target.value })} /></TableCell>
                        <TableCell className="text-right font-semibold">{fmtIDR(l.qty * l.price)}</TableCell>
                        <TableCell><Button size="icon" variant="ghost" onClick={() => setLines(lines.filter((_, x) => x !== i))}><Trash2 className="size-3" /></Button></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="text-right mt-2 text-lg font-semibold">Total: {fmtIDR(total)}</div>
              </div>
              <div><Label>Catatan</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} /></div>
            </div>
            <DialogFooter><Button onClick={save}>Simpan sebagai Draft</Button></DialogFooter>
          </DialogContent>
        </Dialog>}
      />

      <div className="grid grid-cols-4 gap-4 mb-6">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Draft</div><div className="text-2xl font-semibold mt-1">{kpi.draft}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Menunggu Approval</div><div className="text-2xl font-semibold mt-1 text-chart-3">{kpi.pending}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Approved (open)</div><div className="text-2xl font-semibold mt-1 text-primary">{kpi.approved}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Closed</div><div className="text-2xl font-semibold mt-1 text-success">{kpi.closed}</div></CardContent></Card>
      </div>

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>PO No</TableHead><TableHead>Tanggal</TableHead><TableHead>Vendor</TableHead><TableHead>Items</TableHead><TableHead className="text-right">Total</TableHead><TableHead>Status</TableHead><TableHead>Workflow</TableHead></TableRow></TableHeader>
          <TableBody>
            {pos.length === 0 ? <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">Belum ada PO. Klik "Buat PO" untuk mulai.</TableCell></TableRow> :
              pos.map((p) => {
                const v = vendors.find((x) => x.id === p.vendorId);
                return (
                  <TableRow key={p.id}>
                    <TableCell className="font-mono text-xs">{p.poNo}</TableCell>
                    <TableCell className="text-xs">{new Date(p.date).toLocaleDateString()}</TableCell>
                    <TableCell>{v?.name}</TableCell>
                    <TableCell className="text-xs">{p.lines.length} item</TableCell>
                    <TableCell className="text-right font-semibold">{fmtIDR(p.total)}</TableCell>
                    <TableCell><Badge className={statusTone(p.status)}>{p.status}</Badge></TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {p.status === "Draft" && <Button size="sm" variant="outline" onClick={() => { submitPO(p.id); log("Submitted PO", p.poNo, "Procurement", p.id); toast.success("PO submitted"); }}><Send className="size-3" /> Submit</Button>}
                        {p.status === "Submitted" && role === "Administrator" && <>
                          <Button size="sm" onClick={() => { approvePO(p.id); log("Approved PO", p.poNo, "Procurement", p.id); toast.success("PO approved"); }}><CheckCircle2 className="size-3" /> Approve</Button>
                          <Button size="sm" variant="destructive" onClick={() => { rejectPO(p.id); log("Rejected PO", p.poNo, "Procurement", p.id); }}><XCircle className="size-3" /></Button>
                        </>}
                        {p.status === "Submitted" && role !== "Administrator" && <span className="text-xs text-muted-foreground">Menunggu Admin</span>}
                        {p.status === "Approved" && <Badge variant="outline" className="text-xs"><FileText className="size-3 mr-1" /> Siap GR</Badge>}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
