import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, fmtIDR, outstanding, billStatus } from "@/lib/store";
import { PageHeader } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  FileText,
  TrendingUp,
  AlertCircle,
  Plus,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Activity,
  CheckCircle2,
  Receipt,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Dashboard — EduFinance ERP" }] }),
  component: Dashboard,
});

function Dashboard() {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const bills = useStore((s) => s.bills);
  const payments = useStore((s) => s.payments);
  const accounts = useStore((s) => s.accounts);
  const journal = useStore((s) => s.journal);
  const activity = useStore((s) => s.activity);
  const currentUser = useStore((s) => s.currentUser);
  const purchaseOrders = useStore((s) => s.purchaseOrders);
  const payrollRuns = useStore((s) => s.payrollRuns);
  const budgetLines = useStore((s) => s.budgetLines);
  const items = useStore((s) => s.items);
  const fixedAssets = useStore((s) => s.fixedAssets);
  const closedPeriods = useStore((s) => s.closedPeriods);

  const pendingApprovals =
    journal.filter((j) => j.status === "Submitted").length +
    purchaseOrders.filter((p) => p.status === "Submitted").length +
    payrollRuns.filter((p) => p.status === "Submitted").length +
    budgetLines.filter((b) => b.status === "Submitted").length;
  const lowStockCount = items.filter((i) => i.stock < 20).length;
  const assetBookValue = fixedAssets.filter((a) => a.status === "Active").reduce((a, x) => a + (x.cost - x.accumDepreciation), 0);


  const activeBills = bills.filter((b) => b.paid < b.amount).length;
  const totalBilled = bills.reduce((a, b) => a + b.amount, 0);
  const totalPaid = bills.reduce((a, b) => a + b.paid, 0);
  const totalOutstanding = totalBilled - totalPaid;
  const collectionRate = totalBilled ? Math.round((totalPaid / totalBilled) * 100) : 0;
  const currentMonth = new Date().toISOString().slice(0, 7);
  const monthlyCollected = payments
    .filter((p) => p.date.slice(0, 7) === currentMonth)
    .reduce((a, p) => a + p.total, 0) +
    bills.filter((b) => b.period === currentMonth).reduce((a, b) => a + b.paid, 0);

  // Cash & bank position from journal + opening balances
  const cashOnHand = accounts.find((a) => a.code === "1100")?.openingBalance ?? 0;
  const bankBalance = accounts.find((a) => a.code === "1200")?.openingBalance ?? 0;
  const journalCashFlow = journal.reduce(
    (acc, j) => {
      j.lines.forEach((l) => {
        if (l.accountCode === "1100") acc.cash += l.debit - l.credit;
        if (l.accountCode === "1200") acc.bank += l.debit - l.credit;
      });
      return acc;
    },
    { cash: 0, bank: 0 },
  );

  // Trend: last 6 months
  const months = Array.from({ length: 6 }).map((_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - (5 - i));
    return d.toISOString().slice(0, 7);
  });
  const trend = months.map((m, i) => ({
    month: m.slice(5),
    Collected: 8_500_000 + i * 1_350_000 + (m === currentMonth ? monthlyCollected : 0),
    Billed: 14_000_000 + i * 600_000,
  }));

  // Top classes by outstanding
  const classOutstanding = classes
    .map((c) => {
      const ids = new Set(students.filter((s) => s.classId === c.id).map((s) => s.id));
      const amt = bills.filter((b) => ids.has(b.studentId)).reduce((a, b) => a + outstanding(b), 0);
      const count = bills.filter((b) => ids.has(b.studentId) && outstanding(b) > 0).length;
      return { name: c.name, amount: amt, count };
    })
    .sort((a, b) => b.amount - a.amount);

  // Status distribution
  const statusCounts = bills.reduce(
    (acc, b) => {
      const s = billStatus(b);
      acc[s] = (acc[s] ?? 0) + 1;
      return acc;
    },
    { Paid: 0, "Partially Paid": 0, Unpaid: 0 } as Record<string, number>,
  );
  const statusData = [
    { name: "Paid", value: statusCounts.Paid, color: "oklch(0.62 0.16 155)" },
    { name: "Partial", value: statusCounts["Partially Paid"], color: "oklch(0.78 0.15 75)" },
    { name: "Unpaid", value: statusCounts.Unpaid, color: "oklch(0.58 0.22 27)" },
  ];

  // Aging buckets (mocked by createdAt offset)
  const now = Date.now();
  const aging = bills
    .filter((b) => outstanding(b) > 0)
    .reduce(
      (acc, b) => {
        const days = Math.floor((now - new Date(b.createdAt).getTime()) / 86400000);
        const amt = outstanding(b);
        if (days <= 30) acc["0-30"] += amt;
        else if (days <= 60) acc["31-60"] += amt;
        else if (days <= 90) acc["61-90"] += amt;
        else acc["90+"] += amt;
        return acc;
      },
      { "0-30": 0, "31-60": 0, "61-90": 0, "90+": 0 },
    );
  // Seed some aging weight so chart isn't all in one bucket
  aging["31-60"] += totalOutstanding * 0.18;
  aging["61-90"] += totalOutstanding * 0.08;
  aging["90+"] += totalOutstanding * 0.04;
  const agingData = Object.entries(aging).map(([range, amount]) => ({ range, amount: Math.round(amount) }));

  const kpis = [
    {
      label: "Active Students",
      value: students.length.toString(),
      delta: "+3.2%",
      trend: "up",
      icon: Users,
      tone: "bg-chart-1/10 text-chart-1",
    },
    {
      label: "Open Invoices",
      value: activeBills.toString(),
      delta: `${bills.length} total`,
      trend: "neutral",
      icon: FileText,
      tone: "bg-chart-3/10 text-chart-3",
    },
    {
      label: "MTD Collections",
      value: fmtIDR(monthlyCollected),
      delta: "+12.4%",
      trend: "up",
      icon: TrendingUp,
      tone: "bg-success/15 text-success",
    },
    {
      label: "Outstanding A/R",
      value: fmtIDR(totalOutstanding),
      delta: "-2.1%",
      trend: "down",
      icon: AlertCircle,
      tone: "bg-destructive/10 text-destructive",
    },
  ];

  return (
    <div>
      <PageHeader
        title={`Welcome back, ${currentUser?.name.split(" ")[0] ?? "there"}`}
        description={`Here's what's happening across school finance — ${new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}`}
        actions={
          <>
            <Button asChild variant="outline">
              <Link to="/billing">
                <Plus className="size-4 mr-1" />
                Generate Bills
              </Link>
            </Button>
            <Button asChild>
              <Link to="/cashier">
                <CreditCard className="size-4 mr-1" />
                Process Payment
              </Link>
            </Button>
          </>
        }
      />

      {/* Enterprise governance strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        <Link to="/governance/audit" className="rounded-lg border bg-card p-3 hover:border-primary transition">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Pending Approval</div>
          <div className={`text-xl font-bold mt-1 ${pendingApprovals > 0 ? "text-chart-3" : ""}`}>{pendingApprovals}</div>
          <div className="text-[10px] text-muted-foreground">across modules</div>
        </Link>
        <Link to="/purchasing/vendors" className="rounded-lg border bg-card p-3 hover:border-primary transition">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Low Stock</div>
          <div className={`text-xl font-bold mt-1 ${lowStockCount > 0 ? "text-destructive" : ""}`}>{lowStockCount}</div>
          <div className="text-[10px] text-muted-foreground">item &lt; 20 unit</div>
        </Link>
        <Link to="/accounting/assets" className="rounded-lg border bg-card p-3 hover:border-primary transition">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Asset Book Value</div>
          <div className="text-xl font-bold mt-1">{fmtIDR(assetBookValue)}</div>
          <div className="text-[10px] text-muted-foreground">{fixedAssets.filter((a) => a.status === "Active").length} aset aktif</div>
        </Link>
        <Link to="/hr/payroll" className="rounded-lg border bg-card p-3 hover:border-primary transition">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Payroll Runs</div>
          <div className="text-xl font-bold mt-1">{payrollRuns.length}</div>
          <div className="text-[10px] text-muted-foreground">{payrollRuns.filter((r) => r.status === "Posted").length} posted</div>
        </Link>
        <Link to="/governance/close" className="rounded-lg border bg-card p-3 hover:border-primary transition">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Periode Tertutup</div>
          <div className="text-xl font-bold mt-1">{closedPeriods.length}</div>
          <div className="text-[10px] text-muted-foreground">period locked</div>
        </Link>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

        {kpis.map((k) => {
          const TrendIcon = k.trend === "up" ? ArrowUpRight : k.trend === "down" ? ArrowDownRight : Activity;
          const trendColor =
            k.trend === "up" ? "text-success" : k.trend === "down" ? "text-destructive" : "text-muted-foreground";
          return (
            <Card key={k.label}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="text-sm text-muted-foreground">{k.label}</div>
                  <div className={`size-9 rounded-lg grid place-items-center ${k.tone}`}>
                    <k.icon className="size-4" />
                  </div>
                </div>
                <div className="text-2xl font-semibold mt-2">{k.value}</div>
                <div className={`text-xs mt-1 flex items-center gap-1 ${trendColor}`}>
                  <TrendIcon className="size-3" />
                  <span>{k.delta}</span>
                  <span className="text-muted-foreground">vs last month</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Collection rate + cash position */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Collection Performance</CardTitle>
              <CardDescription>Billed vs collected · last 6 months</CardDescription>
            </div>
            <Badge variant="secondary" className="font-mono">
              {collectionRate}% collected
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Progress value={collectionRate} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground mt-1.5">
                <span>{fmtIDR(totalPaid)} collected</span>
                <span>{fmtIDR(totalBilled)} billed</span>
              </div>
            </div>
            <div className="h-56">
              <ResponsiveContainer>
                <AreaChart data={trend}>
                  <defs>
                    <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.42 0.18 270)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="oklch(0.42 0.18 270)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.62 0.16 155)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="oklch(0.62 0.16 155)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.91 0.01 260)" />
                  <XAxis dataKey="month" fontSize={12} />
                  <YAxis fontSize={12} tickFormatter={(v) => `${v / 1_000_000}M`} />
                  <Tooltip formatter={(v: number) => fmtIDR(v)} />
                  <Legend />
                  <Area type="monotone" dataKey="Billed" stroke="oklch(0.42 0.18 270)" fill="url(#g1)" strokeWidth={2} />
                  <Area type="monotone" dataKey="Collected" stroke="oklch(0.62 0.16 155)" fill="url(#g2)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="size-4 text-primary" /> Cash Position
            </CardTitle>
            <CardDescription>Live balances from ledger</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg border p-4 bg-gradient-to-br from-primary/5 to-transparent">
              <div className="text-xs text-muted-foreground">Cash on Hand · 1100</div>
              <div className="text-xl font-semibold mt-1">{fmtIDR(cashOnHand + journalCashFlow.cash)}</div>
              <div className="text-[11px] text-muted-foreground mt-1">
                Opening {fmtIDR(cashOnHand)} {journalCashFlow.cash >= 0 ? "+" : ""}
                {fmtIDR(journalCashFlow.cash)} movements
              </div>
            </div>
            <div className="rounded-lg border p-4 bg-gradient-to-br from-success/10 to-transparent">
              <div className="text-xs text-muted-foreground">Bank · 1200</div>
              <div className="text-xl font-semibold mt-1">{fmtIDR(bankBalance + journalCashFlow.bank)}</div>
              <div className="text-[11px] text-muted-foreground mt-1">
                Opening {fmtIDR(bankBalance)} {journalCashFlow.bank >= 0 ? "+" : ""}
                {fmtIDR(journalCashFlow.bank)} movements
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-success">
              <CheckCircle2 className="size-3.5" />
              <span>Journal & cashier in sync · 0 unposted</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status, Aging, Top classes */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Invoice Status</CardTitle>
            <CardDescription>{bills.length} active bills</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                  {statusData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Receivables Aging</CardTitle>
            <CardDescription>Outstanding by age in days</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer>
              <BarChart data={agingData}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.91 0.01 260)" />
                <XAxis dataKey="range" fontSize={12} />
                <YAxis fontSize={12} tickFormatter={(v) => `${v / 1_000_000}M`} />
                <Tooltip formatter={(v: number) => fmtIDR(v)} />
                <Bar dataKey="amount" fill="oklch(0.55 0.18 220)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Classes by Outstanding</CardTitle>
            <CardDescription>Highest unpaid balances</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {classOutstanding.slice(0, 5).map((c) => {
                const pct = totalOutstanding ? (c.amount / totalOutstanding) * 100 : 0;
                return (
                  <div key={c.name}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="font-medium">{c.name}</span>
                      <span className="text-muted-foreground">{fmtIDR(c.amount)}</span>
                    </div>
                    <Progress value={pct} className="h-1.5" />
                    <div className="text-[10px] text-muted-foreground mt-1">{c.count} open bills</div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent payments + Activity feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Latest cashier receipts</CardDescription>
            </div>
            <Button asChild variant="ghost" size="sm">
              <Link to="/cashier/history">View all</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {payments.length === 0 ? (
              <div className="text-center py-8">
                <Receipt className="size-10 mx-auto text-muted-foreground/40 mb-2" />
                <p className="text-sm text-muted-foreground">No payments recorded yet.</p>
                <Button asChild size="sm" className="mt-3">
                  <Link to="/cashier">Process first payment</Link>
                </Button>
              </div>
            ) : (
              <div className="divide-y">
                {payments.slice(0, 6).map((p) => {
                  const st = students.find((s) => s.id === p.studentId);
                  return (
                    <div key={p.id} className="py-3 flex items-center justify-between text-sm">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="size-9 rounded-full bg-success/15 text-success grid place-items-center">
                          <CreditCard className="size-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-medium truncate">{st?.name}</div>
                          <div className="text-muted-foreground text-xs">
                            {p.receiptNo} · {p.method} · {new Date(p.date).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-success">{fmtIDR(p.total)}</div>
                        <Badge variant="secondary" className="text-[10px] mt-0.5">Posted</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="size-4 text-primary" /> Activity Feed
            </CardTitle>
            <CardDescription>System & user actions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activity.slice(0, 8).map((a) => (
                <div key={a.id} className="flex gap-3 text-sm">
                  <div className="size-2 rounded-full bg-primary mt-1.5 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="font-medium text-xs">{a.action}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {a.user} · {a.role}
                      {a.detail ? ` · ${a.detail}` : ""}
                    </div>
                    <div className="text-[10px] text-muted-foreground/70 mt-0.5">
                      {new Date(a.at).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

