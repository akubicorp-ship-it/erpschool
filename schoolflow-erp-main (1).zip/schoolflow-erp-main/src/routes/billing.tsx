import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useStore, fmtIDR, outstanding, billStatus, exportCSV } from "@/lib/store";
import { FileSpreadsheet, Upload, Wand2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/billing")({
  head: () => ({ meta: [{ title: "Billing — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator"]}><Billing /></RoleGuard>,
});

function Billing() {
  const bills = useStore((s) => s.bills);
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const feeTypes = useStore((s) => s.feeTypes);
  const generate = useStore((s) => s.generateBills);

  const [q, setQ] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(1);
  const perPage = 10;

  const enriched = useMemo(() => bills.map((b) => {
    const st = students.find((s) => s.id === b.studentId)!;
    const ft = feeTypes.find((f) => f.id === b.feeTypeId)!;
    return { ...b, student: st, feeType: ft, status: billStatus(b), out: outstanding(b) };
  }), [bills, students, feeTypes]);

  const filtered = enriched.filter((b) =>
    (q === "" || b.student?.name.toLowerCase().includes(q.toLowerCase())) &&
    (classFilter === "all" || b.student?.classId === classFilter) &&
    (statusFilter === "all" || b.status === statusFilter)
  );
  const pages = Math.max(1, Math.ceil(filtered.length / perPage));
  const view = filtered.slice((page - 1) * perPage, page * perPage);

  // Generate modal
  const [genOpen, setGenOpen] = useState(false);
  const [gen, setGen] = useState({ feeTypeId: "", classId: "", period: new Date().toISOString().slice(0, 7), amount: 0 });

  // Import modal
  const [importOpen, setImportOpen] = useState(false);

  return (
    <div>
      <PageHeader
        title="Billing Monitor"
        description="Generate and track student invoices"
        actions={
          <>
            <Dialog open={importOpen} onOpenChange={setImportOpen}>
              <DialogTrigger asChild><Button variant="outline"><Upload className="size-4 mr-1" />Import Excel</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Import Bills from Excel</DialogTitle>
                  <DialogDescription>Upload an .xlsx file with columns: NIS, Fee Type, Period, Amount</DialogDescription>
                </DialogHeader>
                <Input type="file" accept=".xlsx,.csv" />
                <DialogFooter>
                  <Button onClick={() => { toast.success("Mock import complete · 0 rows processed"); setImportOpen(false); }}>
                    Process
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={genOpen} onOpenChange={setGenOpen}>
              <DialogTrigger asChild><Button><Wand2 className="size-4 mr-1" />Generate Bills</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Mass-generate fee</DialogTitle></DialogHeader>
                <div className="grid gap-3">
                  <div><Label>Fee Type</Label>
                    <Select value={gen.feeTypeId} onValueChange={(v) => {
                      const f = feeTypes.find((x) => x.id === v);
                      setGen({ ...gen, feeTypeId: v, amount: f?.defaultAmount ?? 0 });
                    }}>
                      <SelectTrigger><SelectValue placeholder="Select fee" /></SelectTrigger>
                      <SelectContent>{feeTypes.map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label>Target Class (or all)</Label>
                    <Select value={gen.classId || "all"} onValueChange={(v) => setGen({ ...gen, classId: v === "all" ? "" : v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>Period (YYYY-MM)</Label><Input value={gen.period} onChange={(e) => setGen({ ...gen, period: e.target.value })} /></div>
                  <div><Label>Amount</Label><Input type="number" value={gen.amount || ""} onChange={(e) => setGen({ ...gen, amount: +e.target.value })} /></div>
                </div>
                <DialogFooter>
                  <Button onClick={() => {
                    if (!gen.feeTypeId || !gen.amount || !gen.period) return toast.error("Fill all fields");
                    const n = generate({ feeTypeId: gen.feeTypeId, classId: gen.classId || undefined, period: gen.period, amount: gen.amount });
                    toast.success(`${n} bill(s) generated`);
                    setGenOpen(false);
                  }}>Generate</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Button variant="outline" onClick={() => exportCSV("bills.csv", filtered.map((b) => ({
              NIS: b.student?.nis ?? "", Name: b.student?.name ?? "",
              Class: classes.find((c) => c.id === b.student?.classId)?.name ?? "",
              Fee: b.feeType?.name ?? "", Period: b.period,
              Amount: b.amount, Paid: b.paid, Outstanding: b.out, Status: b.status,
            })))}>
              <FileSpreadsheet className="size-4 mr-1" />Export
            </Button>
          </>
        }
      />

      <Card><CardContent className="p-5">
        <div className="flex flex-wrap gap-2 mb-4">
          <Input placeholder="Search student..." value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} className="max-w-xs" />
          <Select value={classFilter} onValueChange={(v) => { setClassFilter(v); setPage(1); }}>
            <SelectTrigger className="w-44"><SelectValue placeholder="Class" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classes</SelectItem>
              {classes.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
            <SelectTrigger className="w-44"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Unpaid">Unpaid</SelectItem>
              <SelectItem value="Partially Paid">Partially Paid</SelectItem>
              <SelectItem value="Paid">Paid</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Table>
          <TableHeader><TableRow>
            <TableHead>Student</TableHead><TableHead>Class</TableHead><TableHead>Fee Type</TableHead>
            <TableHead>Period</TableHead><TableHead className="text-right">Amount</TableHead>
            <TableHead className="text-right">Outstanding</TableHead><TableHead>Status</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {view.map((b) => (
              <TableRow key={b.id}>
                <TableCell>
                  <div className="font-medium">{b.student?.name}</div>
                  <div className="text-xs text-muted-foreground">{b.student?.nis}</div>
                </TableCell>
                <TableCell>{classes.find((c) => c.id === b.student?.classId)?.name}</TableCell>
                <TableCell>{b.feeType?.name}</TableCell>
                <TableCell>{b.period}</TableCell>
                <TableCell className="text-right">{fmtIDR(b.amount)}</TableCell>
                <TableCell className="text-right font-medium">{fmtIDR(b.out)}</TableCell>
                <TableCell>
                  <Badge variant={b.status === "Paid" ? "default" : b.status === "Partially Paid" ? "secondary" : "destructive"}>
                    {b.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
            {view.length === 0 && (
              <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No bills match your filters</TableCell></TableRow>
            )}
          </TableBody>
        </Table>

        <div className="flex items-center justify-between mt-4 text-sm">
          <div className="text-muted-foreground">{filtered.length} bills</div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" disabled={page === 1} onClick={() => setPage(page - 1)}>Prev</Button>
            <span className="self-center">Page {page} / {pages}</span>
            <Button size="sm" variant="outline" disabled={page === pages} onClick={() => setPage(page + 1)}>Next</Button>
          </div>
        </div>
      </CardContent></Card>
    </div>
  );
}
