import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useStore, fmtIDR, outstanding, type Payment } from "@/lib/store";
import { Printer, Search } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/cashier/")({
  head: () => ({ meta: [{ title: "Cashier — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Cashier"]}><Cashier /></RoleGuard>,
});

function Cashier() {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const bills = useStore((s) => s.bills);
  const feeTypes = useStore((s) => s.feeTypes);
  const banks = useStore((s) => s.bankAccounts);
  const recordPayment = useStore((s) => s.recordPayment);
  const role = useStore((s) => s.role);

  const [q, setQ] = useState("");
  const [selStudent, setSelStudent] = useState<string | null>(null);
  const [method, setMethod] = useState<"Cash" | "Bank Transfer">("Cash");
  const [bankId, setBankId] = useState<string>("");
  const [allocs, setAllocs] = useState<Record<string, number>>({});
  const [receipt, setReceipt] = useState<Payment | null>(null);

  const matches = q.length > 0 ? students.filter((s) =>
    s.name.toLowerCase().includes(q.toLowerCase()) || s.nis.includes(q)
  ).slice(0, 8) : [];

  const studentBills = useMemo(() =>
    selStudent ? bills.filter((b) => b.studentId === selStudent && outstanding(b) > 0) : [],
    [selStudent, bills]
  );

  const totalPay = Object.values(allocs).reduce((a, b) => a + (b || 0), 0);

  const selectStudent = (id: string) => {
    setSelStudent(id);
    setQ(students.find((s) => s.id === id)?.name ?? "");
    setAllocs({});
  };

  const submit = () => {
    const allocations = Object.entries(allocs)
      .filter(([, v]) => v > 0)
      .map(([billId, amount]) => ({ billId, amount }));
    if (!selStudent) return toast.error("Select a student");
    if (allocations.length === 0) return toast.error("Allocate payment to at least one bill");
    for (const a of allocations) {
      const b = bills.find((x) => x.id === a.billId)!;
      if (a.amount > outstanding(b)) return toast.error(`Payment exceeds outstanding for ${feeTypes.find((f) => f.id === b.feeTypeId)?.name}`);
    }
    if (method === "Bank Transfer" && !bankId) return toast.error("Select a bank account");
    const p = recordPayment({ studentId: selStudent, method, bankAccountId: bankId, allocations, cashier: role });
    toast.success("Payment recorded · journal entry auto-posted");
    setReceipt(p);
    setAllocs({});
  };

  const student = students.find((s) => s.id === selStudent);

  return (
    <div>
      <PageHeader title="Cashier" description="Process student payments — multi-bill, partial, with auto-journal" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <Label>Find Student (by name or NIS)</Label>
            <div className="relative mt-1">
              <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input className="pl-9" placeholder="Type to search..." value={q} onChange={(e) => { setQ(e.target.value); setSelStudent(null); }} />
              {matches.length > 0 && !selStudent && (
                <div className="absolute z-10 mt-1 w-full bg-popover border rounded-md shadow-lg max-h-64 overflow-auto">
                  {matches.map((s) => (
                    <button key={s.id} onClick={() => selectStudent(s.id)} className="w-full text-left px-3 py-2 hover:bg-accent text-sm">
                      <div className="font-medium">{s.name}</div>
                      <div className="text-xs text-muted-foreground">{s.nis} · {classes.find((c) => c.id === s.classId)?.name}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {student && (
              <div className="mt-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="font-semibold">{student.name}</div>
                    <div className="text-xs text-muted-foreground">{student.nis} · {classes.find((c) => c.id === student.classId)?.name}</div>
                  </div>
                  <Badge variant="secondary">{studentBills.length} outstanding</Badge>
                </div>

                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="w-10"></TableHead>
                    <TableHead>Fee</TableHead><TableHead>Period</TableHead>
                    <TableHead className="text-right">Outstanding</TableHead>
                    <TableHead className="text-right w-40">Pay Amount</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {studentBills.map((b) => {
                      const out = outstanding(b);
                      const checked = allocs[b.id] !== undefined;
                      return (
                        <TableRow key={b.id}>
                          <TableCell>
                            <Checkbox checked={checked} onCheckedChange={(v) => {
                              const n = { ...allocs };
                              if (v) n[b.id] = out; else delete n[b.id];
                              setAllocs(n);
                            }} />
                          </TableCell>
                          <TableCell>{feeTypes.find((f) => f.id === b.feeTypeId)?.name}</TableCell>
                          <TableCell>{b.period}</TableCell>
                          <TableCell className="text-right">{fmtIDR(out)}</TableCell>
                          <TableCell>
                            <Input
                              type="number"
                              disabled={!checked}
                              value={allocs[b.id] ?? ""}
                              max={out}
                              onChange={(e) => setAllocs({ ...allocs, [b.id]: Math.min(+e.target.value, out) })}
                              className="text-right"
                            />
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {studentBills.length === 0 && (
                      <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">No outstanding bills</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 space-y-4">
            <h3 className="font-semibold">Payment Summary</h3>
            <div>
              <Label>Method</Label>
              <Select value={method} onValueChange={(v) => setMethod(v as "Cash" | "Bank Transfer")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cash">Cash (Tunai)</SelectItem>
                  <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {method === "Bank Transfer" && (
              <div>
                <Label>Bank Account</Label>
                <Select value={bankId} onValueChange={setBankId}>
                  <SelectTrigger><SelectValue placeholder="Select bank" /></SelectTrigger>
                  <SelectContent>
                    {banks.map((b) => <SelectItem key={b.id} value={b.id}>{b.bankName} — {b.accountNo}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="bg-muted rounded-lg p-4">
              <div className="text-xs text-muted-foreground">Total Payment</div>
              <div className="text-2xl font-bold text-primary">{fmtIDR(totalPay)}</div>
            </div>
            <Button className="w-full" size="lg" onClick={submit} disabled={!selStudent || totalPay === 0}>
              Process Payment
            </Button>
            <p className="text-xs text-muted-foreground">
              Every successful payment automatically posts a journal entry: Debit {method} / Credit School Income.
            </p>
          </CardContent>
        </Card>
      </div>

      <ReceiptDialog payment={receipt} onClose={() => setReceipt(null)} />
    </div>
  );
}

export function ReceiptDialog({ payment, onClose }: { payment: Payment | null; onClose: () => void }) {
  const students = useStore((s) => s.students);
  const classes = useStore((s) => s.classes);
  const bills = useStore((s) => s.bills);
  const feeTypes = useStore((s) => s.feeTypes);
  const banks = useStore((s) => s.bankAccounts);

  if (!payment) return null;
  const st = students.find((s) => s.id === payment.studentId);
  const cls = classes.find((c) => c.id === st?.classId);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Payment Receipt</DialogTitle>
        </DialogHeader>
        <div className="print-area p-4 bg-card border rounded-md">
          <div className="text-center border-b pb-3 mb-3">
            <h2 className="font-bold text-lg">SMP Harapan Bangsa</h2>
            <div className="text-xs text-muted-foreground">Official Payment Receipt</div>
          </div>
          <div className="text-sm space-y-1 mb-3">
            <div className="flex justify-between"><span>Receipt #</span><span className="font-mono">{payment.receiptNo}</span></div>
            <div className="flex justify-between"><span>Date</span><span>{new Date(payment.date).toLocaleString()}</span></div>
            <div className="flex justify-between"><span>Student</span><span>{st?.name}</span></div>
            <div className="flex justify-between"><span>NIS / Class</span><span>{st?.nis} · {cls?.name}</span></div>
            <div className="flex justify-between"><span>Method</span><span>{payment.method}{payment.bankAccountId ? ` (${banks.find((b) => b.id === payment.bankAccountId)?.bankName})` : ""}</span></div>
            <div className="flex justify-between"><span>Cashier</span><span>{payment.cashier}</span></div>
          </div>
          <table className="w-full text-sm border-t border-b py-2">
            <thead><tr className="text-left text-xs text-muted-foreground"><th className="py-1">Item</th><th className="text-right">Amount</th></tr></thead>
            <tbody>
              {payment.allocations.map((a) => {
                const b = bills.find((x) => x.id === a.billId);
                const ft = feeTypes.find((f) => f.id === b?.feeTypeId);
                return (
                  <tr key={a.billId}><td className="py-1">{ft?.name} ({b?.period})</td><td className="text-right">{fmtIDR(a.amount)}</td></tr>
                );
              })}
            </tbody>
          </table>
          <div className="flex justify-between font-bold text-base mt-3">
            <span>TOTAL</span><span>{fmtIDR(payment.total)}</span>
          </div>
          <div className="text-center text-xs text-muted-foreground mt-6">Thank you for your payment.</div>
        </div>
        <div className="flex justify-end gap-2 no-print">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button onClick={() => window.print()}><Printer className="size-4 mr-1" />Print</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
