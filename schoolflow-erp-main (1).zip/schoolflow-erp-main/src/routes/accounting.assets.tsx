import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, RoleGuard } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useStore, fmtIDR } from "@/lib/store";
import { Plus, Calendar, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/accounting/assets")({
  head: () => ({ meta: [{ title: "Fixed Assets — EduFinance ERP" }] }),
  component: () => <RoleGuard allow={["Administrator", "Accounting"]}><Page /></RoleGuard>,
});

function Page() {
  const assets = useStore((s) => s.fixedAssets);
  const lastDep = useStore((s) => s.lastDepreciation);
  const addAsset = useStore((s) => s.addAsset);
  const disposeAsset = useStore((s) => s.disposeAsset);
  const runDep = useStore((s) => s.runDepreciation);
  const log = useStore((s) => s.logActivity);

  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ code: "", name: "", category: "Elektronik", acquisitionDate: new Date().toISOString().slice(0, 10), cost: 0, usefulLifeMonths: 60 });

  const totalCost = assets.filter((a) => a.status === "Active").reduce((a, x) => a + x.cost, 0);
  const totalDep = assets.filter((a) => a.status === "Active").reduce((a, x) => a + x.accumDepreciation, 0);
  const bookValue = totalCost - totalDep;

  const currentPeriod = new Date().toISOString().slice(0, 7);

  return (
    <div>
      <PageHeader title="Fixed Assets" description="Manajemen aset tetap dengan penyusutan otomatis bulanan (straight-line) yang langsung post ke jurnal"
        actions={<>
          <Button variant={lastDep === currentPeriod ? "outline" : "default"} onClick={() => {
            if (lastDep === currentPeriod) return toast.info("Penyusutan untuk periode ini sudah dijalankan");
            const total = runDep(currentPeriod);
            log("Ran depreciation", `${currentPeriod} — ${fmtIDR(total)}`, "Assets");
            toast.success(`Penyusutan ${currentPeriod}: ${fmtIDR(total)} di-post ke jurnal`);
          }}><Calendar className="size-4" /> {lastDep === currentPeriod ? `Sudah dijalankan ${currentPeriod}` : `Run Depreciation ${currentPeriod}`}</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4" /> Tambah Aset</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Aset Tetap Baru</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Kode</Label><Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
                <div><Label>Kategori</Label><Input value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /></div>
                <div className="col-span-2"><Label>Nama</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
                <div><Label>Tanggal Perolehan</Label><Input type="date" value={f.acquisitionDate} onChange={(e) => setF({ ...f, acquisitionDate: e.target.value })} /></div>
                <div><Label>Harga Perolehan</Label><Input type="number" value={f.cost} onChange={(e) => setF({ ...f, cost: +e.target.value })} /></div>
                <div className="col-span-2"><Label>Masa Manfaat (bulan)</Label><Input type="number" value={f.usefulLifeMonths} onChange={(e) => setF({ ...f, usefulLifeMonths: +e.target.value })} /></div>
              </div>
              <DialogFooter><Button onClick={() => { if (!f.code || !f.cost) return toast.error("Kode & harga wajib"); addAsset(f); log("Added asset", f.name, "Assets"); setOpen(false); toast.success("Aset ditambahkan"); }}>Simpan</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </>}
      />

      <div className="grid grid-cols-4 gap-4 mb-6">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Total Aset Aktif</div><div className="text-2xl font-semibold mt-1">{assets.filter((a) => a.status === "Active").length}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Harga Perolehan</div><div className="text-2xl font-semibold mt-1">{fmtIDR(totalCost)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Akumulasi Penyusutan</div><div className="text-2xl font-semibold mt-1 text-destructive">{fmtIDR(totalDep)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Nilai Buku</div><div className="text-2xl font-semibold mt-1 text-primary">{fmtIDR(bookValue)}</div></CardContent></Card>
      </div>

      <Card><CardContent className="p-6">
        <Table>
          <TableHeader><TableRow><TableHead>Kode</TableHead><TableHead>Nama</TableHead><TableHead>Kategori</TableHead><TableHead>Tgl Perolehan</TableHead><TableHead className="text-right">Cost</TableHead><TableHead className="text-right">Akm.Dep</TableHead><TableHead className="text-right">Nilai Buku</TableHead><TableHead className="w-32">Penyusutan</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {assets.map((a) => {
              const bv = a.cost - a.accumDepreciation;
              const pct = (a.accumDepreciation / a.cost) * 100;
              return (
                <TableRow key={a.id}>
                  <TableCell className="font-mono text-xs">{a.code}</TableCell>
                  <TableCell className="font-medium">{a.name}</TableCell>
                  <TableCell><Badge variant="secondary">{a.category}</Badge></TableCell>
                  <TableCell className="text-xs">{new Date(a.acquisitionDate).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">{fmtIDR(a.cost)}</TableCell>
                  <TableCell className="text-right text-destructive">{fmtIDR(a.accumDepreciation)}</TableCell>
                  <TableCell className="text-right font-semibold">{fmtIDR(bv)}</TableCell>
                  <TableCell><Progress value={pct} className="h-2" /><div className="text-[10px] mt-0.5 text-muted-foreground">{Math.round(pct)}% disusutkan</div></TableCell>
                  <TableCell>{a.status === "Active" ? <Badge className="bg-success/15 text-success">Aktif</Badge> : <Badge variant="secondary">Disposed</Badge>}</TableCell>
                  <TableCell>{a.status === "Active" && <Button size="sm" variant="ghost" onClick={() => { disposeAsset(a.id); log("Disposed asset", a.name, "Assets"); }}><AlertCircle className="size-3" /></Button>}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
